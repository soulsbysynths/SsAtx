/*
* AtxCSequencer.cpp
*
* Created: 14/06/2018 11:35:00
* Author: info
*/


#include "AtxCSequencer.h"

// default constructor
AtxCSequencer::AtxCSequencer(AtxCSequencerBase* base, AtxZone* zonePtrs[])
{
	construct(base,zonePtrs);
} //AtxCSequencer

// default destructor
AtxCSequencer::~AtxCSequencer()
{
	if (base_!=NULL)
	{
		delete base_;
	}
} //~AtxCSequencer

void AtxCSequencer::construct(AtxCSequencerBase* base, AtxZone* zonePtrs[])
{
	using namespace Atx;
	base_ = base;
	for (uint_fast8_t i=0;i<MAX_ZONES;++i)
	{
		zone_[i] = zonePtrs[i];
	}
}

void AtxCSequencer::initialize()
{
	setBpm(120);
	
	//test notes
	AtxMsg m;
	uint16_t t;
	static const uint8_t STARTNOTE = 12;
	for (uint8_t c=0;c<5;++c)
	{
		t = 0;
		sequence_[c][0].clear();
		for (uint8_t n=STARTNOTE;n<(STARTNOTE+16);++n)
		{
			m.setHeader(AtxMsg::AMH_NOTEON);
			//m.setMsgByte(1,MidiMsg::MCMD_NOTEON | c);
			m.setMidiData(0,n + ((c+2)*12));
			m.setMidiData(1,127);
			m.setClkStamp(t);
			sequence_[c][0].append(m);
			m.setHeader(AtxMsg::AMH_NOTEOFF);
			//m.setMsgByte(1,MidiMsg::MCMD_NOTEOFF | c);
			m.setMidiData(0,n + ((c+2)*12));
			m.setMidiData(1,0);
			m.setClkStamp(t+5);
			sequence_[c][0].append(m);
			t += 6;
		}
		sequence_[c][0].setName("Sequenc0",8);
		sequence_[c][0].looping = true;
	}
	for (uint8_t c=0;c<5;++c)
	{
		t = 0;
		sequence_[c][1].clear();
		for (uint8_t n=(STARTNOTE+16);n>STARTNOTE;--n)
		{
			m.setHeader(AtxMsg::AMH_NOTEON);
			//m.setMidiData(1,MidiMsg::MCMD_NOTEON | c);
			m.setMidiData(0,n + ((c+2)*12));
			m.setMidiData(1,127);
			m.setClkStamp(t);
			sequence_[c][1].append(m);
			m.setHeader(AtxMsg::AMH_NOTEOFF);
			//m.setMsgByte(1,MidiMsg::MCMD_NOTEOFF | c);
			m.setMidiData(0,n + ((c+2)*12));
			m.setMidiData(1,0);
			m.setClkStamp(t+5);
			sequence_[c][1].append(m);
			t += 6;
		}
		sequence_[c][1].setName("Sequenc1",8);
		sequence_[c][1].looping = true;
	}
	initSeqBuffer();
}

void AtxCSequencer::setBpm(uint16_t newValue)
{
	if (newValue<20)
	{
		newValue = 20;
	}
	else if(newValue>300)
	{
		newValue = 300;
	}
	bpm_ = newValue;
	base_->sequencerBpmChanged(bpm_);
}

uint8_t AtxCSequencer::getEventListIndex(uint_fast8_t zone)
{
	return editIndex_[zone][editSeq_[zone]];
}

void AtxCSequencer::setSequenceName(uint_fast8_t zone, uint_fast8_t seq, char * newName, size_t len)
{
	sequence_[zone][seq].setName(newName,len);
	refreshOverviewName(zone,seq,calcDisplay(zone),calcRow(zone,seq));
}

void AtxCSequencer::setSequenceBars(uint_fast8_t zone, uint_fast8_t seq, uint16_t newBars)
{
	sequence_[zone][seq].setLength(getClksPerBar(zone,seq) * newBars);
	if (isOverviewMode())
	{
		refreshOverviewName(zone,seq,calcDisplay(zone),calcRow(zone,seq));
	}
}

void AtxCSequencer::toggleCue()
{
	using namespace Atx;
	if (sequence_[editZone_][editSeq_[editZone_]].playState==AtxMsgList::PS_STOP)
	{
		setPlayState(editZone_,editSeq_[editZone_],AtxMsgList::PS_CUE);
	}
	else
	{
		setPlayState(editZone_,editSeq_[editZone_],AtxMsgList::PS_STOP);
	}
}

void AtxCSequencer::toggleLoop()
{
	setLoop(editZone_,editSeq_[editZone_],!sequence_[editZone_][editSeq_[editZone_]].looping);
}

void AtxCSequencer::pollClk()
{
	using namespace Atx;
	if (seqPlayMode_==SPM_STOP)
	{
		return;
	}
	
	if (clk_ % clksPerBar_==0)  //new bar
	{
		//AtxMsg m;  //NO THIS ISN@T THE WAY TO MCMD_SPP
		//m.setHeader(AtxMsg::AMH_COMMON3);
		//m.setMsgByte(1,MidiMsg::MCMD_SPP);
		//uint32_t beats = clk_ / 6;
		//m.setMsgByte(2,beats & 0x7F);
		//m.setMsgByte(3,(beats >> 7) & 0x7F);
		//base_->sequencerTxCard(I2C_GENERAL_CALL,&m);
		for (uint_fast8_t i=0;i<MAX_ZONES;++i)
		{
			for (uint_fast8_t j=0;j<MAX_SEQS;++j)
			{
				if (sequence_[i][j].playState==AtxMsgList::PS_CUE)
				{
					if (seqPlayMode_==SPM_REC && i==editZone_)
					{
						seqBuffer_.reset();
						seqBuffer_.playState = AtxMsgList::PS_REC;
						setPlayState(i,j,AtxMsgList::PS_REC);
					}
					else
					{
						setPlayState(i,j,AtxMsgList::PS_PLAY);
					}
				}
			}

		}
	}
	if (seqPlayMode_==SPM_REC)
	{
		if (clk_ % clksPerBeat_==0)  //new beat
		{
			AtxMsg m;
			m.setHeader(AtxMsg::AMH_NOTEON);
			m.setMidiCard(clickCard_);
			m.setMidiData(0,clickNote_);
			m.setMidiData(1,127);
			base_->sequencerTxCard(clickCard_,&m);
			clickOffClk_ = clk_ + (clksPerBeat_ >> 2);
		}
		else if(clk_==clickOffClk_)
		{
			AtxMsg m;
			m.setHeader(AtxMsg::AMH_NOTEOFF);
			m.setMidiCard(clickCard_);
			m.setMidiData(0,clickNote_);
			base_->sequencerTxCard(clickCard_,&m);
		}
	}

	for (uint_fast8_t i=0;i<MAX_ZONES;++i)
	{
		AtxMsgList * seqTiming = &sequence_[i][playSeq_[i]];
		AtxMsgList * seqNotes;
		if ((sequence_[i][playSeq_[i]].playState==AtxMsgList::PS_REC || seqMsgMode_[SI_TRANSMSG]!=SMM_OFF) && i==editZone_)
		{
			seqNotes = &seqBuffer_;
		}
		else
		{
			seqNotes = &sequence_[i][playSeq_[i]];
		}
		if (seqTiming->playState==AtxMsgList::PS_PLAY)
		{
			seqNotes->clk = seqTiming->clk;
			while (seqNotes->isMsgAtClk())
			{
				base_->sequencerTxZone(i,&seqNotes->getPlayMsg());
				if (!seqNotes->incIndex())
				{
					seqNotes->setIndex(0);
					break;
				}
			}
			seqTiming->clk++;
			if (seqTiming->clk>=seqTiming->getLength())
			{
				if (seqTiming->looping==false)
				{
					setPlayState(i,playSeq_[i],AtxMsgList::PS_STOP);
				}
				else
				{
					sequence_[i][playSeq_[i]].reset();
				}
			}
		}
		

	}
	if (seqMsgMode_[SI_ADDMSG]!=SMM_OFF)
	{
		while (seqBuffer_.isMsgAtClk())
		{
			base_->sequencerTxZone(editZone_,&seqBuffer_.getPlayMsg());
			if (!seqBuffer_.incIndex())
			{
				seqBuffer_.setIndex(0);
				break;
			}
		}
	}
	seqBuffer_.clk++;
	if (seqBuffer_.clk>=seqBuffer_.getLength())  //always loop
	{
		if (seqBuffer_.playState==AtxMsgList::PS_REC && seqBuffer_.looping==true)
		{
			seqBuffer_.playState = AtxMsgList::PS_PLAY;
			setPlayState(editZone_,playSeq_[editZone_],AtxMsgList::PS_PLAY);
		}
		seqBuffer_.reset();
	}
	clk_++;
}

void AtxCSequencer::setPlayState(uint_fast8_t zone, uint_fast8_t seq, AtxMsgList::PlayState newState)
{
	sequence_[zone][seq].playState = newState;
	sequence_[zone][seq].reset();  //as far as I can tell, all changes in state require reset
	switch(newState)
	{
		case AtxMsgList::PS_STOP:
		zone_[zone]->allNotesOff(); //stop any playing note
		break;
		case AtxMsgList::PS_CUE:
		for (uint_fast8_t i=0;i<MAX_SEQS;++i)
		{
			if (i!=seq && sequence_[zone][i].playState==AtxMsgList::PS_CUE)
			{
				setPlayState(zone,i,AtxMsgList::PS_STOP);
			}
		}
		break;
		case AtxMsgList::PS_PLAY:
		case AtxMsgList::PS_REC:
		playSeq_[zone] = seq; //still playseq even tho rec
		for (uint_fast8_t i=0;i<MAX_SEQS;++i)
		{
			if (i!=seq && sequence_[zone][i].playState==AtxMsgList::PS_PLAY)
			{
				setPlayState(zone,i,AtxMsgList::PS_STOP);
			}
		}
		if (newState==AtxMsgList::PS_REC)
		{
			zone_[zone]->allNotesOff(); //stop any playing note
			initSeqBuffer();
		}
		break;
	}
	
	if (isOverviewMode() && isOverviewSeqVisible(zone,seq))
	{
		base_->sequencerOvPlayChanged(zone,seq,(isSelected(zone) & seq==editSeq_[zone]),newState,calcDisplay(zone),calcRow(zone,seq));
	}
}


void AtxCSequencer::setLoop(uint_fast8_t zone, uint_fast8_t seq, bool newLoop)
{
	sequence_[zone][seq].looping = newLoop;
	if (isOverviewMode() && isOverviewSeqVisible(zone,seq))
	{
		base_->sequencerOvSeqLoopChanged(zone,seq,sequence_[zone][seq].looping,calcDisplay(zone),calcRow(zone,seq));
	}
}

void AtxCSequencer::setEditSeq(uint_fast8_t zone, uint8_t newSeq)
{
	editSeq_[zone] = newSeq;
	if (isOverviewMode())
	{
		refreshOverviewZone(zone);  //need to update whole zone, because scrolling up/down
	}
	else if (seqMode_==S_ADDMSG)
	{
		initSeqBuffer();
	}
}

void AtxCSequencer::pollOv()
{
	using namespace Atx;
	static uint32_t lastClk = 0;
	static uint8_t lastPos[MAX_ZONES][MAX_SEQS] = {{0}};
	if (isOverviewMode())
	{
		for (uint_fast8_t z=0;z<MAX_ZONES;++z)
		{
			for (uint_fast8_t s=0;s<MAX_SEQS;++s)
			{
				if (isOverviewSeqVisible(z,s) && sequence_[z][s].getLength())
				{
					uint8_t newPos = calcPos(z,s);
					if (newPos!=lastPos[z][s])
					{
						lastPos[z][s] = newPos;
						base_->sequencerOvSeqPosChanged(z,s,newPos,calcDisplay(z),calcRow(z,s));
					}
				}
			}
		}
	}
	if(seqMode_==S_OVERVIEW)
	{
		if (clk_!=lastClk)
		{
			lastClk = clk_;
			base_->sequencerOvClkChanged(calcBar(clk_),calcBeat(clk_),calcClk(clk_));
		}
	}
}


void AtxCSequencer::setPlayMode(SeqPlayMode newMode)
{
	using namespace Atx;
	switch(newMode)
	{
		case SPM_STOP:
		if(clickOffClk_>clk_)  //stop metronome
		{
			AtxMsg m;
			m.setHeader(AtxMsg::AMH_NOTEOFF);
			m.setMidiCard(clickCard_);
			m.setMidiData(0,clickNote_);
			base_->sequencerTxCard(clickCard_,&m);
		}
		for (uint_fast8_t i=0;i<MAX_ZONES;++i)
		{
			setPlayState(i,playSeq_[i],AtxMsgList::PS_STOP);
		}
		seqBuffer_.playState = AtxMsgList::PS_STOP;
		break;
		case SPM_PLAY:
		if (seqPlayMode_==SPM_STOP)
		{
			clk_ = 0;
			seqBuffer_.reset();
		}
		seqBuffer_.playState = AtxMsgList::PS_PLAY;
		for (uint_fast8_t i=0;i<MAX_ZONES;++i)
		{
			for (uint_fast8_t j=0;j<MAX_SEQS;++j)
			{
				if (seqPlayMode_==SPM_STOP)
				{
					sequence_[i][j].reset();
				}
				if (sequence_[i][j].playState==AtxMsgList::PS_CUE)
				{
					setPlayState(i,j,AtxMsgList::PS_PLAY);
				}
			}
		}
		break;
		case SPM_REC:
		if (seqPlayMode_==SPM_STOP)
		{
			clk_ = 0;
			//seqBuffer_.reset();
		}
		//seqBuffer_.playState = AtxMsgList::PS_PLAY;
		for (uint_fast8_t i=0;i<MAX_ZONES;++i)
		{
			for (uint_fast8_t j=0;j<MAX_SEQS;++j)
			{
				if (seqPlayMode_==SPM_STOP)
				{
					sequence_[i][j].reset();
				}
				if (sequence_[i][j].playState==AtxMsgList::PS_CUE)
				{
					if (i==editZone_)
					{
						setPlayState(i,j,AtxMsgList::PS_REC);
					}
					else
					{
						setPlayState(i,j,AtxMsgList::PS_PLAY);
					}
				}
			}
		}
		break;
	}
	seqPlayMode_ = newMode;
	AtxMsg m;
	if (seqPlayMode_==AtxCSequencer::SPM_STOP)
	{
		m.setHeader(AtxMsg::AMH_REALTIMEBYTE);
		m.setMidiCmd(MidiMsg::MCMD_STOP);
		base_->sequencerTxCard(I2C_GENERAL_CALL,&m);
		//delay(1);  //eek remove!
	}
	else
	{
		m.setHeader(AtxMsg::AMH_REALTIMEBYTE);
		m.setMidiCmd(MidiMsg::MCMD_START);
		base_->sequencerTxCard(I2C_GENERAL_CALL,&m);
	}
	base_->sequencerPlayChanged((uint8_t)seqPlayMode_);
}


bool AtxCSequencer::isSelected(uint_fast8_t zone)
{
	return (zone==editZone_);
}

void AtxCSequencer::remapMidiToSequence(char * fileName)
{
	using namespace Atx;
	uint8_t ppqnRatio = midiList_.getClksPerQuarterNote() / CLKS_PER_QUARTER_NOTE;
	sequence_[editZone_][editSeq_[editZone_]].clear();
	uint32_t ts = 0;
	for (uint_fast16_t i=0;i<midiList_.getCount();++i)
	{
		uint8_t cmd,ch,n,v;
		AtxMsg m;
		cmd = midiList_.getEvent(i).getCommand() & 0xF0;
		//ch = midiList_.getEvent(i).getCommand() & 0x0F;
		n = midiList_.getEvent(i).getData1();
		v = midiList_.getEvent(i).getData2();
		if (cmd==MidiMsg::MCMD_NOTEON && v==0)
		{
			cmd = MidiMsg::MCMD_NOTEOFF;
		}
		ts += midiList_.getEvent(i).getDeltaTime();
		switch (cmd)
		{
			case MidiMsg::MCMD_NOTEON:
			{
				m.setHeader(AtxMsg::AMH_NOTEON);
				//m.setMsgByte(1,(MidiMsg::MCMD_NOTEON | editZone_));  //no point setting that here
				m.setMidiData(0,n);
				m.setMidiData(1,v);
				m.setClkStamp(ts / ppqnRatio);
				sequence_[editZone_][editSeq_[editZone_]].append(m);
			}
			break;
			case MidiMsg::MCMD_NOTEOFF:
			{
				m.setHeader(AtxMsg::AMH_NOTEOFF);
				//m.setMsgByte(1,(MidiMsg::MCMD_NOTEOFF | editZone_));  //no point setting that here
				m.setMidiData(0,n);
				m.setClkStamp(ts / ppqnRatio);
				sequence_[editZone_][editSeq_[editZone_]].append(m);
			}
			break;
		}
	}
	setSequenceName(editZone_,editSeq_[editZone_],fileName,8);
	//sequence_[editZone_][editSeq_[editZone_]].setName(fileName,8);
	//base_->sequencerOvSeqNameChanged(editZone_,1,sequence_[editZone_][editSeq_[editZone_]].getNamePtr(),calcDisplay(editZone_),calcRow(editZone_,editSeq_[editZone_]));
}

//YOU NEED TO COME BACK TO THIS TO CHECK IT
void AtxCSequencer::remapMpeToSequence()
{
	//using namespace Atx;
	//uint8_t cmd, ch;
	//uint16_t chInUse = 0;
	//for (uint16_t i=0;i<midiList_.getCount();++i)
	//{
	//cmd = midiList_.getEvent(i).getCommand() & 0xF0;
	//ch = midiList_.getEvent(i).getCommand() & 0x0F;
	//if (cmd<0xF0)  //ignore sys common msgs
	//{
	//bitSet(chInUse,ch);
	//}
	//}
	//uint16_t chToVoiceMap[16];
	//uint8_t v = 0;
	//for (uint8_t i = 0;i<16;++i)
	//{
	//chToVoiceMap[i] = UNUSED;
	//if (bitRead(chInUse,i)==true)
	//{
	//while (card_[v]->zone!=card_[editZone_]->zone)
	//{
	//v++;
	//v &= 0x07;
	//}
	//chToVoiceMap[i] = v;
	//v++;
	//v &= 0x07;
	//}
	//}
	//for (uint8_t i=0;i<MAX_SYNTHCARDS;++i)
	//{
	//if (card_[i]->zone==card_[editZone_]->zone)
	//{
	//sequence_[i][1-actSeq_[i]].clear();
	//}
	//}
	//uint16_t ts = 0;
	//for (uint_fast16_t i=0;i<midiList_.getCount();++i)
	//{
	//cmd = midiList_.getEvent(i).getCommand() & 0xF0;
	//ch = midiList_.getEvent(i).getCommand() & 0x0F;
	//switch (cmd)
	//{
	//case MidiMsg::MCMD_NOTEON:
	//case MidiMsg::MCMD_NOTEOFF:
	//{
	//AtxMsg m;
	//if (cmd==MidiMsg::MCMD_NOTEON)
	//{
	//m.setHeader(AtxMsg::AMH_NOTEON);
	//m.setMsgByte(1,MidiMsg::MCMD_NOTEON | chToVoiceMap[ch]);
	//}
	//else
	//{
	//m.setHeader(AtxMsg::AMH_NOTEOFF);
	//m.setMsgByte(1,MidiMsg::MCMD_NOTEOFF | chToVoiceMap[ch]);
	//}
	//
	//m.setMsgByte(2,midiList_.getEvent(i).getData1());
	//m.setMsgByte(3,midiList_.getEvent(i).getData2());
	//m.setClkStamp(ts);
	//sequence_[chToVoiceMap[ch]][1-actSeq_[chToVoiceMap[ch]]].append(m);
	//}
	//break;
	//}
	//ts += midiList_.getEvent(i).getDeltaTime();
	//}
}

void AtxCSequencer::setEditZone(uint8_t newZone)
{
	using namespace Atx;
	static uint8_t editPage = 0xFF;  //force first refresh
	uint8_t newPage = newZone / DISPLAY_COLS;
	if (seqMode_==S_ADDMSG && seqMsgMode_[SI_ADDMSG]!=SMM_OFF)
	{
		txSeqAddParamBufferMsg();
	}
	if (newPage==editPage && isOverviewMode())
	{
		base_->sequencerOvPlayChanged(editZone_,editSeq_[editZone_],false,sequence_[editZone_][editSeq_[editZone_]].playState,calcDisplay(editZone_),calcRow(editZone_,editSeq_[editZone_]));
	}
	editZone_ = newZone;

	if (seqMode_==S_ADDMSG && seqMsgMode_[SI_ADDMSG]!=SMM_OFF)
	{
		updateSeqAddParamBufferMsg();
	}
	
	base_->sequencerEditZoneChanged(editZone_);
	switch(seqMode_)
	{
		case S_EVENTLIST:
		setEventListIndex(editZone_,editIndex_[editZone_][editSeq_[editZone_]]);
		break;
		case S_ADDMSG:
		base_->sequencerAddTransBouncedChanged(seqAddTransBounced_);
		paramList_.buildParamList(zone_[editZone_]->firmware);
		initSeqBuffer();
		calcSeqAddParam();
		break;
		case S_TRANSMSG:
		initSeqBuffer();
		break;
	}
	if (newPage==editPage)
	{
		if (isOverviewMode())
		{
			base_->sequencerOvPlayChanged(editZone_,editSeq_[editZone_],true,sequence_[editZone_][editSeq_[editZone_]].playState,calcDisplay(editZone_),calcRow(editZone_,editSeq_[editZone_]));  //add sel to new seq
		}
		
	}
	else
	{
		editPage = newPage;
		refreshOverviewPage(editPage);
	}
}

bool AtxCSequencer::setEditZoneFromCtrl(uint8_t ctrl)
{
	uint8_t page = editZone_ / DISPLAY_COLS;
	uint8_t newZone = (page * DISPLAY_COLS)  + ctrl;
	if (newZone >= Atx::MAX_ZONES)
	{
		return false;
	}
	else
	{
		if (zone_[newZone]->getCards())
		{
			if (newZone!=editZone_)
			{
				setEditZone(newZone);
			}
			return true;
		}
		else
		{
			return false;
		}
	}
}

//uint8_t AtxCSequencer::calcPos(uint_fast8_t zone, uint_fast8_t index)  //play pos 0 = 0, otherwise 1 - 8
//{
//if (sequence_[zone][index].clk==0)
//{
//return 0;
//}
//else
//{
//return ((sequence_[zone][index].clk << 3) / sequence_[zone][index].getLength())+1;
//}
//}

uint8_t AtxCSequencer::calcPos(uint_fast8_t zone, uint_fast8_t index)  //play pos 0 - 63
{
	if (sequence_[zone][index].getLength()==0)
	{
		return 0;
	}
	else
	{
		return (((uint32_t)sequence_[zone][index].clk << 6) / sequence_[zone][index].getLength());
	}
}

void AtxCSequencer::setSeqMode(SeqMode newMode)
{
	seqMode_ = newMode;
	seqModeIndex_ = newMode - S_ADDMSG;
	if (seqModeIndex_>=SI_MAX)
	{
		seqModeIndex_ = SI_ADDMSG;  //safety
	}
	base_->sequencerModeChanged(seqMode_);
	using namespace Atx;
	switch(seqMode_)
	{
		case S_EVENTLIST:
		setEventListIndex(editZone_,editIndex_[editZone_][editSeq_[editZone_]]);
		break;
		case S_ADDMSG:
		case S_TRANSMSG:
		setSeqMsgMode(seqMsgMode_[seqModeIndex_]);
		setSeqAddTransBounced(seqAddTransBounced_[seqModeIndex_]);
		break;
		case S_OVERVIEW:
		base_->sequencerOvClkChanged(calcBar(clk_),calcBeat(clk_),calcClk(clk_));
		break;
	}
	if (seqMode_!=S_ADDMSG)
	{
		txSeqAddParamBufferMsg();
	}
	if (isOverviewMode())
	{
		refreshOverviewPage(editZone_/DISPLAY_COLS);
	}
	else
	{
		if (seqPlayMode_==SPM_REC)
		{
			setPlayMode(SPM_PLAY);
		}
		for (uint_fast8_t i=0;i<DISPLAY_COLS;++i)
		{
			base_->sequencerDisplayOnMapChanged(0xFF);
		}
	}
}

void AtxCSequencer::refreshOverviewPage(uint_fast8_t page)
{
	uint8_t f = page * DISPLAY_COLS;
	uint8_t l = f + DISPLAY_COLS;
	uint8_t o = 0, onMap = 0b11000000;
	for (uint_fast8_t i=0;i<MAX_SEQS;++i)
	{
		seqOverviewVisible_[i] = 0;
	}
	for (uint_fast8_t i=f;i<l;++i)
	{
		if(i<Atx::MAX_ZONES)
		{
			if (zone_[i]->getCards())
			{
				refreshOverviewZone(i);
				bitSet(onMap,o);
			}
		}
		else
		{
			break;
		}
		o++;
	}
	base_->sequencerDisplayOnMapChanged(onMap);
}

void AtxCSequencer::refreshOverviewZone(uint_fast8_t zone)
{
	if (zone_[zone]->getCards()==0)
	{
		return;
	}
	uint_fast8_t f,l;

	if (editSeq_[zone]>(MAX_SEQS-DISPLAY_ROWS))
	{
		f = MAX_SEQS - DISPLAY_ROWS;
		l = MAX_SEQS;
	}
	else
	{
		f = editSeq_[zone];
		l = editSeq_[zone] + DISPLAY_ROWS;
	}
	for (uint_fast8_t i=0;i<MAX_SEQS;++i)
	{
		if (i>f || i<l)
		{
			bitSet(seqOverviewVisible_[i],zone);
			refreshOverviewSeq(zone,i);
		}
		else
		{
			bitClear(seqOverviewVisible_[i],zone);
		}

	}
}

void AtxCSequencer::refreshOverviewSeq(uint_fast8_t zone, uint_fast8_t seq)
{
	uint8_t d = calcDisplay(zone);
	uint8_t r = calcRow(zone,seq);
	base_->sequencerOvSeqChanged(zone,seq,d,r);
	base_->sequencerOvPlayChanged(zone,seq,(zone==editZone_ && seq==editSeq_[zone]),sequence_[zone][seq].playState,d,r);
	base_->sequencerOvSeqLoopChanged(zone,seq,sequence_[zone][seq].looping,d,r);
	refreshOverviewName(zone,seq,d,r);
	base_->sequencerOvSeqPosChanged(zone,seq,calcPos(zone,seq),d,r);
}

void AtxCSequencer::refreshOverviewName(uint_fast8_t zone, uint_fast8_t seq, uint_fast8_t display, uint_fast8_t row)
{
	if(seqMode_==S_LENGTH)
	{
		char name[9];
		uint16_t l = sequence_[zone][seq].getLength();
		uint16_t bars = l / getClksPerBar();
		if (bars==1)
		{
			snprintf(name, 9, "%d bar", bars);
		}
		else
		{
			snprintf(name, 9, "%d bars", bars);
		}
		base_->sequencerOvSeqNameChanged(zone,seq,name,display,row);
	}
	else
	{
		base_->sequencerOvSeqNameChanged(zone,seq,sequence_[zone][seq].getNamePtr(),display,row);
	}
}

void AtxCSequencer::setSeqBufferMode(SeqBufferMode newMode)
{
	seqBufferMode_ = newMode;
	
	base_->sequencerBufferModeChanged(seqBufferMode_);
}

void AtxCSequencer::appendSeqBuffer(AtxMsg * msg)
{
	if (seqBuffer_.playState==AtxMsgList::PS_REC)
	{
		msg->setClkStamp(seqBuffer_.clk);
		seqBuffer_.append(*msg);
	}
}

void AtxCSequencer::setEventListIndex(uint_fast8_t zone, uint16_t newIndex)
{
	editIndex_[zone][editSeq_[zone]] = newIndex;
	base_->sequencerEventListChanged(newIndex,&sequence_[zone][editSeq_[zone]].getMsg(editIndex_[zone][editSeq_[zone]]));
}

uint16_t AtxCSequencer::calcBar(uint32_t clkStamp)
{
	return (clkStamp / getClksPerBar()) + 1;
}

uint8_t AtxCSequencer::calcBeat(uint32_t clkStamp)
{
	return ((clkStamp % getClksPerBar()) / getClksPerBeat()) + 1;
}

uint8_t AtxCSequencer::calcClk(uint32_t clkStamp)
{
	return clkStamp % getClksPerBeat();
}

//void AtxCSequencer::initSeqAdd()
void AtxCSequencer::initSeqBuffer()
{
	seqBuffer_.clear();  //surely always clear first?
	if (seqMode_==S_ADDMSG)
	{
		seqBuffer_.setCapacity(SEQ_WAVELEN);
		seqBuffer_.setBeatsPerBar(sequence_[editZone_][editSeq_[editZone_]].getBeatsPerBar());
		seqBuffer_.setClksPerBeat(sequence_[editZone_][editSeq_[editZone_]].getClksPerBeat());
		seqBuffer_.setLength(sequence_[editZone_][editSeq_[editZone_]].getLength());
		for (uint_fast8_t i=0;i<SEQ_WAVELEN;++i)
		{
			seqBuffer_.getMsgPtr(i)->setHeader(AtxMsg::AMH_PARAM);
		}
		calcSeqAddTrans();
	}
	else if(seqMode_==S_TRANSMSG)
	{
	}
	else if(isOverviewMode())  //the rec buffer
	{
		seqBuffer_.setBeatsPerBar(sequence_[editZone_][playSeq_[editZone_]].getBeatsPerBar());
		seqBuffer_.setClksPerBeat(sequence_[editZone_][playSeq_[editZone_]].getClksPerBeat());
		seqBuffer_.setLength(sequence_[editZone_][playSeq_[editZone_]].getLength());
	}
}

void AtxCSequencer::setSeqAddTransValue(uint_fast8_t seqParam, int16_t value)
{
	const uint8_t M = seqModeIndex_;
	const uint8_t N = seqMsgModeIndex_[seqModeIndex_];
	
	if (seqMsgMode_[M]==SMM_OFF) return;
	
	//COME BACK!!
	if (getSeqParamInfoPtr(seqParam)->dispFmt==SFMT_START && value>=seqAddTransValue_[M][N][seqParam+1])   //assumes all seq modes will have start and end on index 4 and 5
	{
		value = seqAddTransValue_[M][N][seqParam+1]-1;
	}
	else if (getSeqParamInfoPtr(seqParam)->dispFmt==SFMT_END && value<=seqAddTransValue_[M][N][seqParam-1])
	{
		value = seqAddTransValue_[M][N][seqParam-1]+1;
	}
	else if (seqMsgMode_[M]==SMM_PARAM && seqParam==SAP_PARAM)
	{
		txSeqAddParamBufferMsg();
		if (value>=paramList_.getListSize())
		{
			value = paramList_.getListSize() - 1;
		}
	}

	seqAddTransValue_[M][N][seqParam] = value;
	if (seqMode_==S_ADDMSG && (seqMsgMode_[M]==SMM_PARAM && seqParam==SAP_PARAM) || (seqMsgMode_[M]==SMM_NOTES && seqParam==SAB_NOTE))
	{
		updateSeqAddParamBufferMsg();
	}
	
	base_->sequencerAddTransValueChanged(seqParam,value);
	if (seqMode_==S_TRANSMSG && seqParam==STP_TYPE_INDEX)
	{
		base_->sequencerMsgModeChanged(seqMsgMode_[M]);
		for (uint_fast8_t i=0;i<STP_TYPE_INDEX;++i)
		{
			if (seqAddTransValue_[M][N][i]<getSeqParamInfoPtr(i)->rngLow)
			{
				seqAddTransValue_[M][N][i] = getSeqParamInfoPtr(i)->rngLow;
			}
			else if(seqAddTransValue_[M][N][i]>=getSeqParamInfoPtr(i)->rngHigh)
			{
				seqAddTransValue_[M][N][i] = getSeqParamInfoPtr(i)->rngHigh - 1;
			}
			base_->sequencerAddTransValueChanged(i,seqAddTransValue_[M][N][i]);
		}
	}

	calcSeqAddTrans();
}

void AtxCSequencer::calcSeqAddParam()
{
	const uint8_t CLK_INC_SCALE = 4;  //because shortest fill = 1/16
	const uint8_t M = seqModeIndex_;
	const uint8_t N = seqMsgModeIndex_[seqModeIndex_];
	uint16_t clksOneCycle = SEQ_WAVELEN;
	uint16_t clksLen = seqBuffer_.getLength();
	if (seqAddTransValue_[M][N][SAP_RATIO]>0)
	{
		clksOneCycle <<= seqAddTransValue_[M][N][SAP_RATIO];
	}
	else if (seqAddTransValue_[M][N][SAP_RATIO]<0)
	{
		clksOneCycle >>= (seqAddTransValue_[M][N][SAP_RATIO]*-1);
	}
	
	uint16_t clkStart = (clksLen*seqAddTransValue_[M][N][SAP_START])>>4; // 0-15
	uint16_t clkEnd = (clksLen*seqAddTransValue_[M][N][SAP_END]) >> 4; // 1-16 (16 = 100%)
	uint16_t clksActiveArea = clkEnd - clkStart;
	
	uint16_t clkIncScaled = ((uint32_t)clksActiveArea<<4) / SEQ_WAVELEN;  //so if act area = 1 bar, inc = 16
	uint16_t clkScaled = clkStart << 4;
	uint16_t clk = clkScaled >> 4;
	uint16_t lastClk = 0;
	uint16_t indexIncScaled = (clksActiveArea << 4) / clksOneCycle; //same as total cycles

	uint16_t indexScaled = 0;
	uint8_t index = indexScaled >> 4;
	uint8_t paramBits = AtxCard::getParamInfoPtr(zone_[editZone_]->firmware,seqAddTransValue_[M][N][SAP_PARAM])->bits;
	uint8_t pixels[48] = {0};
	uint8_t x;
	uint8_t seqIndex = 0;
	uint16_t lastWave = 0;
	while (clk<clkEnd)
	{
		
		uint16_t wave = ((uint16_t)SEQ_WAVETABLES[seqAddTransValue_[M][N][SAP_WAVE]][index] * seqAddTransValue_[M][N][SAP_AMP]) >> 7;  //128 = *1
		int16_t offsetWave = (int16_t)wave + ((int16_t)seqAddTransValue_[M][N][SAP_OFFSET]);
		wave = constrainUChar(offsetWave);
		x = (clk * 48) / clksLen;
		pixels[x] = wave >> 4;
		if (paramBits>8)
		{
			wave <<= (paramBits-8);
		}
		else if (paramBits<8)
		{
			wave >>= (8-paramBits);
		}
		if (seqIndex==0 || wave!=lastWave)
		{
			AtxMsg * m = seqBuffer_.getMsgPtr(seqIndex);
			m->setClkStamp(clk);
			m->setParam(seqAddTransValue_[M][N][SAP_PARAM]);
			m->setValue(wave);
			lastWave = wave;
			if (clk!=lastClk)
			{
				seqIndex++;
				lastClk = clk;
			}
		}
		clkScaled += clkIncScaled;
		clk = clkScaled >> 4;
		indexScaled += indexIncScaled;
		indexScaled %= SEQ_WAVELEN_SCALED;
		index = indexScaled >> 4;
	}
	seqBuffer_.setCount(seqIndex);
	for (uint_fast8_t i=x;i<48;++i)
	{
		pixels[i] = pixels[x];
	}
	uint8_t xStart = (clkStart * 48) / clksLen;
	for (uint_fast8_t i=0;i<xStart;++i)
	{
		pixels[i] = pixels[x];
	}
	if (seqMode_==S_ADDMSG && seqMsgMode_[M]==SMM_PARAM)
	{
		base_->sequencerAddTransOutputChanged(pixels,false);
	}
}

void AtxCSequencer::calcSeqAddBeats()
{
	const uint8_t CLK_INC_SCALE = 7;
	const uint8_t M = seqModeIndex_;
	const uint8_t N = seqMsgModeIndex_[seqModeIndex_];
	uint16_t clksLen = seqBuffer_.getLength();
	uint8_t pixels[48] = {0};
	uint16_t clk = (clksLen * seqAddTransValue_[M][N][SAB_START]) >> 4;
	uint16_t clkEnd = (clksLen * seqAddTransValue_[M][N][SAB_END]) >> 4;
	uint8_t lastPattClk = 0xFF;
	uint8_t seqIndex = 0;
	bool fill = false;
	uint8_t x = (clk * 48) / clksLen;
	uint8_t w = ((clkEnd * 48) / clksLen) - x;
	memset(&pixels[x],(seqAddTransValue_[M][N][SAB_VEL]>>3),w);
	while(clk<clkEnd && seqIndex<(SEQ_WAVELEN-1))
	{
		uint8_t pattClk = ((clk >> seqAddTransValue_[M][N][SAB_RATIO]) + (seqAddTransValue_[M][N][SAB_PHASE]*6))  % SEQ_WAVELEN;
		if (pattClk!=lastPattClk)
		{
			lastPattClk = pattClk;
			AtxMsg::AtxMsgHdr hdr = calcPatternHeader(seqAddTransValue_[M][N][SAB_PATTERN],pattClk);
			if (hdr!=AtxMsg::AMH_BLANK)
			{
				AtxMsg * m = seqBuffer_.getMsgPtr(seqIndex);
				seqIndex++;
				m->setHeader(hdr);
				m->setMsgByte(2,seqAddTransValue_[M][N][SAB_NOTE]);
				m->setMsgByte(3,seqAddTransValue_[M][N][SAB_VEL]);
				m->setClkStamp(clk);
				if (hdr==AtxMsg::AMH_NOTEON)
				{
					fill = true;
					m->setMsgByte(1,MidiMsg::MCMD_NOTEON | editZone_);
				}
				else if (hdr==AtxMsg::AMH_NOTEOFF)
				{
					fill = false;
					m->setMsgByte(1,MidiMsg::MCMD_NOTEOFF | editZone_);
				}
			}

		}
		
		if (fill==false)  //trying to force gaps in
		{
			uint8_t x = (clk * 48) / clksLen;
			pixels[x] = 0;
		}
		clk++;
	}
	if (clk<clksLen)
	{
		AtxMsg * m = seqBuffer_.getMsgPtr(seqIndex);
		seqIndex++;
		m->setHeader(AtxMsg::AMH_NOTEOFF);
		m->setMsgByte(1,seqAddTransValue_[M][N][SAB_NOTE]);
		m->setMsgByte(1,seqAddTransValue_[M][N][SAB_VEL]);
		m->setClkStamp(clk);
	}
	seqBuffer_.setCount(seqIndex);
	//for (uint_fast8_t i=seqIndex;i<SEQ_WAVELEN;++i)
	//{
	//AtxMsg * m = seqBuffer_.getMsgPtr(i);
	//m->clear();
	//}
	if (seqMode_==S_ADDMSG && seqMsgMode_[M]==SMM_BEATS)
	{
		base_->sequencerAddTransOutputChanged(pixels,true);
	}
}

void AtxCSequencer::calcSeqAddTrans()
{
	switch (seqMode_)
	{
		case S_ADDMSG:
		switch(seqMsgMode_[SI_ADDMSG])
		{
			case SMM_PARAM:
			calcSeqAddParam();
			break;
			case SMM_BEATS:
			calcSeqAddBeats();
			break;
		}
		seqBuffer_.findIndex();
		break;
		case S_TRANSMSG:
		switch(seqMsgMode_[SI_TRANSMSG])
		{
			case SMM_PARAM:
			calcSeqTransParam();
			break;
			case SMM_BEATS:
			break;
		}
		seqBuffer_.findIndex();
		break;
	}
}



void AtxCSequencer::calcSeqTransParam()
{
	const uint8_t C = editZone_;
	const uint8_t D = editSeq_[editZone_];
	const uint8_t M = seqModeIndex_;
	const uint8_t N = seqMsgModeIndex_[seqModeIndex_];
	//seqBuffer_.operator = (sequence_[editZone_][actSeq_[editZone_]]);
	switch(seqAddTransValue_[M][N][STP_TYPE_INDEX])
	{
		case STPT_CLEAR:
		{
			uint16_t tsl = (sequence_[C][D].getLength() * seqAddTransValue_[M][N][1]) >> 4;
			uint16_t tsh = (sequence_[C][D].getLength() * seqAddTransValue_[M][N][2]) >> 4;
			if (seqBuffer_.getCapacity()!=sequence_[C][D].getCapacity())
			{
				seqBuffer_.setCapacity(sequence_[C][D].getCapacity());
			}
			seqBuffer_.setCount(0);
			for (uint16_t i=0;i<sequence_[C][D].getCount();++i)
			{
				AtxMsg * m = sequence_[C][D].getMsgPtr(i);
				uint8_t h = m->getHeader();
				uint8_t p = m->getParam();
				uint16_t ts = m->getClkStamp();
				if (h!=AtxMsg::AMH_PARAM || (h==AtxMsg::AMH_PARAM && (p!=seqAddTransValue_[M][N][0] || (p==seqAddTransValue_[M][N][0] && (ts<tsl || ts>=tsh)))))
				{
					//seqBuffer_.append(sequence_[C][D].getMsg(i));
					seqBuffer_.getMsg(seqBuffer_.getCount()) = sequence_[C][D].getMsg(i);
					seqBuffer_.incCount();
				}
			}
		}
		break;
	}
}

AtxMsg::AtxMsgHdr AtxCSequencer::calcPatternHeader(uint_fast8_t pattNum, uint8_t clk)
{
	uint8_t index = clk >> 5;
	uint32_t mask = 1<<(clk & 0x1F);
	
	if (SEQ_BEATS[pattNum][0][index] & mask)
	{
		return AtxMsg::AMH_NOTEON;
	}
	else if (SEQ_BEATS[pattNum][1][index] & mask)
	{
		return AtxMsg::AMH_NOTEOFF;
	}
	else
	{
		return AtxMsg::AMH_BLANK;
	}
}

void AtxCSequencer::setSeqMsgMode(SeqMsgMode newMode)
{
	const uint8_t M = seqModeIndex_;

	seqMsgMode_[M] = newMode;
	seqMsgModeIndex_[M] = newMode - SMM_PARAM;
	const uint8_t N = seqMsgModeIndex_[seqModeIndex_];
	
	if (seqMsgMode_[M]>SMM_OFF)
	{
		setSeqAddTransBounced(false);
		if (seqMode_==S_ADDMSG)
		{
			txSeqAddParamBufferMsg();
			initSeqBuffer();
		}
	}

	switch (newMode)
	{
		case SMM_OFF:
		break;
		default:
		calcSeqAddTrans();
		for (uint_fast8_t i=0;i<7;++i)
		{
			if (i<6)
			{
				if (seqAddTransValue_[M][N][i]<getSeqParamInfoPtr(i)->rngLow)
				{
					seqAddTransValue_[M][N][i] = getSeqParamInfoPtr(i)->rngLow;
				}
				else if(seqAddTransValue_[M][N][i]>=getSeqParamInfoPtr(i)->rngHigh)
				{
					seqAddTransValue_[M][N][i] = getSeqParamInfoPtr(i)->rngHigh - 1;
				}
			}
			base_->sequencerAddTransValueChanged(i,seqAddTransValue_[M][N][i]);
		}
		break;
	}
	
	if (seqMode_==S_ADDMSG && seqMsgMode_[M]!=SMM_OFF)
	{
		updateSeqAddParamBufferMsg();
	}
	base_->sequencerMsgModeChanged(newMode);
}


void AtxCSequencer::txSeqAddParamBufferMsg()
{
	if (seqAddBufferMsg_.getHeader()!=AtxMsg::AMH_BLANK)
	{
		base_->sequencerTxZone(editZone_,&seqAddBufferMsg_);
		seqAddBufferMsg_.setHeader(AtxMsg::AMH_BLANK);
	}
}

void AtxCSequencer::updateSeqAddParamBufferMsg()
{
	const uint8_t M = seqModeIndex_;
	const uint8_t N = seqMsgModeIndex_[seqModeIndex_];
	seqAddBufferMsg_.clear();
	switch(seqMsgMode_[M])
	{
		case SMM_PARAM:
		{
			seqAddBufferMsg_.setHeader(AtxMsg::AMH_PARAM);
			seqAddBufferMsg_.setParam(seqAddTransValue_[M][N][SAP_PARAM]);
			uint8_t mc = zone_[editZone_]->getMasterCard();
			uint16_t v = zone_[editZone_]->getCardPtr(mc)->getParamValue(seqAddTransValue_[M][N][SAP_PARAM]);
			seqAddBufferMsg_.setValue(v);
		}
		break;
		case SMM_NOTES:
		seqAddBufferMsg_.setHeader(AtxMsg::AMH_NOTEOFF);
		seqAddBufferMsg_.setMsgByte(1,seqAddTransValue_[M][N][SAB_NOTE]);
		seqAddBufferMsg_.setMsgByte(2,seqAddTransValue_[M][N][SAB_VEL]);
		break;
	}

}

void AtxCSequencer::setSeqAddTransBounced(bool newBounced)
{
	const uint8_t M = seqModeIndex_;

	seqAddTransBounced_[M] = newBounced;
	if (seqMode_==S_ADDMSG || seqMode_==S_TRANSMSG)
	{
		base_->sequencerAddTransBouncedChanged(seqAddTransBounced_[M]);
	}
}

void AtxCSequencer::bounceSeqAdd()
{
	const uint8_t M = seqModeIndex_;

	if (seqAddTransBounced_[M]==true) return;
	sequence_[editZone_][editSeq_[editZone_]].merge(seqBuffer_);
	sequence_[editZone_][editSeq_[editZone_]].findIndex();
	setSeqMsgMode(SMM_OFF);
	setSeqAddTransBounced(true);
}

const SeqParamInfo * AtxCSequencer::getSeqParamInfoPtr(uint_fast8_t param)
{
	const uint8_t M = seqModeIndex_;
	const uint8_t N = seqMsgModeIndex_[seqModeIndex_];
	if (seqMode_==S_ADDMSG)
	{
		return &SEQ_ADD_INFO[N][param];
	}
	else if(seqMode_==S_TRANSMSG)
	{
		return &SEQ_TRANS_INFO[N][seqAddTransValue_[M][N][STP_TYPE_INDEX]][param];
	}
	return NULL;
}
