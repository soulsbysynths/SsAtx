/*
* AtxCSequencer.h
*
* Created: 14/06/2018 11:35:00
* Author: info
*/


#ifndef __ATXCSEQUENCER_H__
#define __ATXCSEQUENCER_H__
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <vector>
#include "Atx.h"
#include "AtxCSequencerBase.h"
#include "AtxMsgList.h"
#include "MidiMsgList.h"
#include "AtxCard.h"
#include "AtxZone.h"
#include "AtxCSequencerProgmem.h"
#include "AtxParamList.h"
#include "SsHelpers.h"

#ifndef bitRead
#define bitRead(value, bit) (((value) >> (bit)) & 0x01)
#endif
#ifndef bitSet
#define bitSet(value, bit) ((value) |= (1UL << (bit)))
#endif
#ifndef bitClear
#define bitClear(value, bit) ((value) &= ~(1UL << (bit)))
#endif
#ifndef bitWrite
#define bitWrite(value, bit, bitvalue) (bitvalue ? bitSet(value, bit) : bitClear(value, bit))
#endif

class AtxCSequencer
{
	//variables
	public:
	enum SeqMode : uint8_t
	{
		S_OVERVIEW = 0,
		S_LENGTH,
		S_IMPORTMIDI,
		S_LOADSEQ,
		S_SAVESEQ,
		S_EVENTLIST,
		S_ADDMSG,  //trans must be add + 1
		S_TRANSMSG,
		S_MAX
	};
	enum SeqModeIndex : uint8_t
	{
		SI_ADDMSG = 0,  
		SI_TRANSMSG,
		SI_MAX
	};
	enum SeqDispFmt : uint8_t
	{
		SFMT_NOTHING = 0,
		SFMT_PARAM = 1,
		SFMT_MULTRATIO = 2,  //  -4 = /16, -3 = /8, -2 = /4, -1 = /2, 0 = x1, 1 = x2, 3 = x4, 4 = x8, 5 = x16, 6 = x32, 7 = x64, 8 = x128
		SFMT_INT = 3,
		SFMT_START = 4,
		SFMT_END = 5,
		SFMT_NOTE = 6
	};
	enum SeqTransParamType : uint8_t
	{
		STPT_CLEAR = 0,
		STPT_INVERT,
		STPT_RETROGRADE,
		STPT_MAX
	};
	enum SeqTransBeatType : uint8_t
	{
		
	};
	enum SeqTransNotesType : uint8_t
	{
		
	};
	enum SeqMsgMode : uint8_t
	{
		SMM_OFF = 0,
		SMM_PARAM,
		SMM_BEATS,
		SMM_NOTES,
		SMM_MAX
	};
	enum SeqAddParam : uint8_t
	{
		SAP_PARAM = 0,
		SAP_RATIO,	// /16, /8, /4, /2, 1, *2, *4, *8
		SAP_AMP,  //0-128, for 100% amplitude
		SAP_OFFSET,		//0-255 offset bias
		SAP_START,		//0 - 15, 16 steps
		SAP_END,		//1-16, 16 steps
		SAP_WAVE,
		SAP_MAX
	};
	enum SeqAddBeats : uint8_t
	{
		SAB_NOTE = 0,
		SAB_RATIO,
		SAB_VEL,
		SAB_PHASE,
		SAB_START,
		SAB_END,
		SAB_PATTERN,
		SAB_MAX
	};
	enum SeqPlayMode : uint8_t
	{
		SPM_STOP = 0,
		SPM_PLAY,
		SPM_REC
	};
	enum SeqBufferMode: uint8_t
	{
		SBM_IDLE = 0,
		SBM_CHANGED,
		SBM_REVIEW,
		SMB_BOUNCE	
	};
	const static uint8_t MAX_SEQS_BS = 3;
	const static uint8_t MAX_SEQS = 1 << MAX_SEQS_BS;
	static const uint8_t CLKS_PER_QUARTER_NOTE = 24;
	static const uint8_t DISPLAY_COLS = 6;
	static const uint8_t DISPLAY_ROWS = 2;
	static const uint8_t PAGES = ((Atx::MAX_ZONES - 1) / DISPLAY_COLS) + 1;
	const static uint8_t STP_TYPE_INDEX = 6;
	protected:
	private:
	const static uint16_t SEQ_MODE_OVERVIEW = 0b0000000000011111;
	static const int8_t I2C_GENERAL_CALL = -8;
	AtxCSequencerBase* base_;
	//AtxCard * card_[Atx::MAX_CARDS];  //pointers to the cards
	AtxZone * zone_[Atx::MAX_ZONES];
	SeqMode seqMode_ = S_OVERVIEW;
	uint8_t seqModeIndex_ = 0;	//used for accessing zero aligned arrays for AddTrans
	AtxMsgList sequence_[Atx::MAX_ZONES][MAX_SEQS];
	//AtxMsgList seqAdd_;
	//AtxMsgList seqTrans_;
	AtxMsgList seqBuffer_;
	SeqBufferMode seqBufferMode_ = SBM_IDLE;
	uint8_t seqOverviewVisible_[MAX_SEQS] = {0};  //uint8_t for 8 MAX_ZONES
	MidiMsgList midiList_;
	uint16_t editIndex_[Atx::MAX_ZONES][MAX_SEQS] = {{0}};
	uint8_t editZone_ = 0;	//all these don't need to be stored in a patch
	uint8_t editFunc_[Atx::MAX_ZONES] = {0};
	uint8_t editSeq_[Atx::MAX_ZONES] = {0};
	uint8_t playSeq_[Atx::MAX_ZONES] = {0};	
	uint16_t bpm_ = 120;
	uint32_t clk_ = 0;
	uint8_t clksPerBeat_ = CLKS_PER_QUARTER_NOTE;  //for the sequencer, not the sequence
	uint8_t beatsPerBar_ = 4;  //for the sequencer, not the sequence
	uint8_t clksPerBar_ = clksPerBeat_ * beatsPerBar_;  //for sequencer.  Must keep this synced.
	SeqPlayMode seqPlayMode_ = SPM_STOP;
	SeqMsgMode seqMsgMode_[SI_MAX] = {SMM_OFF};
	uint8_t seqMsgModeIndex_[SI_MAX]  = {0};  //used for accessing zero aligned arrays for AddTrans
	int16_t seqAddTransValue_[SI_MAX][STPT_MAX][7] =
	{
		{
			{1,0,128,0,0,16,0},
			{60,0,127,0,0,16,0},
			{60,0,127,0,0,16,0}
		},
		{
			{1,5,128,128,0,16,0},
			{60,0,127,0,0,16,0},
			{60,0,127,0,0,16,0}
		}
	};
	AtxMsg seqAddBufferMsg_;
	bool seqAddTransBounced_[SI_MAX] = {false};
	uint8_t clickCard_ = 7;
	uint8_t clickNote_ = 37;
	uint32_t clickOffClk_ = 0;
	AtxParamList paramList_;
	//functions
	public:
	static AtxCSequencer& getInstance()
	{
		static AtxCSequencer instance; // Guaranteed to be destroyed.
		return instance;  // Instantiated on first use.
	}
	void pollClk();
	void pollOv();
	void initialize();
	//void construct(AtxCSequencerBase* base, AtxCard* cardPtrs[]);
	void construct(AtxCSequencerBase* base, AtxZone* zonePtrs[]);
	void setSeqMode(SeqMode newMode);
	SeqMode getSeqMode(){return seqMode_;}
	MidiMsgList& getMidiList() { return midiList_; }
	const MidiMsgList& getMidiList() const { return midiList_; }
	AtxMsgList& getSequence(uint_fast8_t zone, bool act){return sequence_[zone][(uint8_t)act==editSeq_[zone]];}
	const AtxMsgList& getSequence(uint_fast8_t zone, bool act) const {return sequence_[zone][(uint8_t)act==editSeq_[zone]];}
	AtxMsgList& getSequence(){return getSequence(editZone_,true);}
	const AtxMsgList& getSequence() const {return getSequence(editZone_,true);}
	void setEditZone(uint8_t newZone);
	uint8_t getEditZone(){return editZone_;}
	bool setEditZoneFromCtrl(uint8_t ctrl);  //return if valid/visible zone
	void setEditSeq(uint_fast8_t zone, uint8_t newSeq);
	void setEditSeq(uint8_t newSeq){setEditSeq(editZone_,newSeq);}
	uint8_t getEditSeq(uint_fast8_t zone){return editSeq_[zone];}
	uint8_t getEditSeq(){return editSeq_[editZone_];}
	void setEventListIndex(uint_fast8_t zone, uint16_t newIndex);
	void setEventListIndex(uint16_t newIndex){setEventListIndex(editZone_,newIndex);}
	uint8_t getEventListIndex(uint_fast8_t zone);
	uint8_t getEventListIndex(){return getEventListIndex(editZone_);}
	uint8_t getClksPerBar(uint_fast8_t zone, uint_fast8_t seq){return sequence_[zone][seq].getClksPerBeat() * sequence_[zone][seq].getBeatsPerBar();}
	uint8_t getClksPerBar(uint_fast8_t zone){return getClksPerBar(zone,editSeq_[zone]);}
	uint8_t getClksPerBar(){return getClksPerBar(editZone_);}
	uint8_t getClksPerBeat(uint_fast8_t zone, uint_fast8_t seq){return sequence_[zone][seq].getClksPerBeat();}
	uint8_t getClksPerBeat(uint_fast8_t zone){return getClksPerBeat(zone,editSeq_[zone]);}
	uint8_t getClksPerBeat(){return getClksPerBeat(editZone_);}
	uint8_t getBeatsPerBar(uint_fast8_t zone, uint_fast8_t seq){return sequence_[zone][seq].getBeatsPerBar();}
	uint8_t getBeatsPerBar(uint_fast8_t zone){return getBeatsPerBar(zone,editSeq_[zone]);}
	uint8_t getBeatsPerBar(){return getBeatsPerBar(editZone_);}
	uint16_t getSequenceCount(uint_fast8_t zone, uint_fast8_t seq){return sequence_[zone][seq].getCount();}
	uint16_t getSequenceCount(uint_fast8_t zone){return getSequenceCount(zone,editSeq_[zone]);}
	uint16_t getSequenceCount(){return getSequenceCount(editZone_);}
	void setSequenceName(uint_fast8_t zone, uint_fast8_t seq, char * newName, size_t len);
	void setSequenceBars(uint_fast8_t zone, uint_fast8_t seq, uint16_t newBars);
	void setSequenceBars(uint16_t newBars){setSequenceBars(editZone_,editSeq_[editZone_],newBars);}
	void setBpm(uint16_t newValue);
	AtxMsgList::PlayState getPlayState(uint_fast8_t zone, uint_fast8_t seq){return sequence_[zone][seq].playState;}
	AtxMsgList::PlayState getPlayState(uint_fast8_t zone){return getPlayState(zone,editSeq_[zone]);}
	AtxMsgList::PlayState getPlayState(){return getPlayState(editZone_);}
	void setPlayState(uint_fast8_t zone, uint_fast8_t seq, AtxMsgList::PlayState newState);
	void setPlayState(uint_fast8_t seq, AtxMsgList::PlayState newState){setPlayState(editZone_,newState);}
	void setPlayState(AtxMsgList::PlayState newState){setPlayState(editZone_,newState);}
	void setLoop(uint_fast8_t zone, uint_fast8_t seq, bool newLoop);
	void setLoop(uint_fast8_t zone, bool newLoop){setLoop(zone,editSeq_[zone],newLoop);}
	void setLoop(bool newLoop){setLoop(editZone_,newLoop);}
	void setPlayMode(SeqPlayMode newMode);
	SeqPlayMode getPlayMode(){return seqPlayMode_;}
	SeqBufferMode getSeqBufferMode(){return seqBufferMode_;}
	void setSeqBufferMode(SeqBufferMode newMode);
	void appendSeqBuffer(AtxMsg * msg);
	uint16_t calcBar(uint32_t clkStamp);
	uint8_t calcBeat(uint32_t clkStamp);
	uint8_t calcClk(uint32_t clkStamp);
	uint8_t calcPos(uint_fast8_t zone, uint_fast8_t index);
	bool isSelected(uint_fast8_t zone);
	void remapMpeToSequence();
	void remapMidiToSequence(char * fileName);
	void toggleCue();
	void toggleLoop();
	const SeqParamInfo * getSeqParamInfoPtr(uint_fast8_t param);
	const char* const getSeqTransNamePtr(){return SEQ_TRANS_NAME[seqMsgModeIndex_[SI_TRANSMSG]][seqAddTransValue_[SI_TRANSMSG][seqMsgModeIndex_[SI_TRANSMSG]][STP_TYPE_INDEX]];}
	//void initSeqAdd();
	//void initSeqTrans();
	void initSeqBuffer();
	int16_t getSeqAddTransValue(uint_fast8_t seqParam){return seqAddTransValue_[seqModeIndex_][seqMsgModeIndex_[seqModeIndex_]][seqParam];}
	void setSeqAddTransValue(uint_fast8_t seqParam, int16_t value);
	void setSeqMsgMode(SeqMsgMode newMode);
	SeqMsgMode getSeqMsgMode(){return seqMsgMode_[seqMode_-S_ADDMSG];}
	void bounceSeqAdd();
	void bounceSeqTrans(){}
	void setSeqAddTransBounced(bool newBounced);
	bool isOverviewMode(){return bitRead(SEQ_MODE_OVERVIEW,(uint8_t)seqMode_);}
	bool isOverviewSeqVisible(uint_fast8_t zone, uint_fast8_t seq){return bitRead(seqOverviewVisible_[seq],zone);}
	protected:
	private:
	AtxCSequencer() {}
	//AtxCSequencer(AtxCSequencerBase* base, AtxCard* cardPtrs[]);
	AtxCSequencer(AtxCSequencerBase* base, AtxZone* zonePtrs[]);
	~AtxCSequencer();
	AtxCSequencer( const AtxCSequencer &c );
	AtxCSequencer& operator=( const AtxCSequencer &c );
	//void toggleActSeq(uint_fast8_t zone);
	//void toggleActSeq(){toggleActSeq(editZone_);}
	void calcSeqAddParam();
	void calcSeqAddBeats();
	void calcSeqAddTrans();
	void calcSeqTransParam();
	void refreshOverviewPage(uint_fast8_t page);
	void refreshOverviewZone(uint_fast8_t zone);
	void refreshOverviewSeq(uint_fast8_t zone, uint_fast8_t seq);
	void refreshOverviewName(uint_fast8_t zone, uint_fast8_t seq, uint_fast8_t display, uint_fast8_t row);
	void txSeqAddParamBufferMsg();
	void updateSeqAddParamBufferMsg();
	AtxMsg::AtxMsgHdr calcPatternHeader(uint_fast8_t pattNum, uint8_t clk);
	uint8_t calcDisplay(uint_fast8_t zone){return (zone % DISPLAY_COLS);}
	uint8_t calcRow(uint_fast8_t zone, uint_fast8_t seq){return ((editSeq_[zone]>(MAX_SEQS-DISPLAY_ROWS)) ? (seq + DISPLAY_ROWS - MAX_SEQS) : (seq - editSeq_[zone]));}
}; //AtxCSequencer

#endif //__ATXCSEQUENCER_H__

