/*
* AtxCSequencer.cpp
*
* Created: 14/06/2018 11:35:00
* Author: info
*/


#include "AtxCSequencer.h"

// default constructor
AtxCSequencer::AtxCSequencer(AtxCSequencerBase* base, AtxZone* zonePtrs[])
{
	construct(base,zonePtrs);
} //AtxCSequencer

// default destructor
AtxCSequencer::~AtxCSequencer()
{
	if (base_!=NULL)
	{
		delete base_;
	}
} //~AtxCSequencer

void AtxCSequencer::construct(AtxCSequencerBase* base, AtxZone* zonePtrs[])
{
	using namespace Atx;
	base_ = base;
	for (uint_fast8_t i=0;i<MAX_ZONES;++i)
	{
		zone_[i] = zonePtrs[i];
	}
}

void AtxCSequencer::initialize()
{
	setBpm(120);
	
	//test notes
	AtxSeqMsg m;
	uint16_t t;
	static const uint8_t STARTNOTE = 12;
	for (uint8_t z=0;z<Atx::MAX_ZONES;++z)
	{
		//base_->sequencerMemoryFree(freeMem);
		for (uint8_t s=0;s<MAX_SEQS;++s)
		{
			t = 0;
			sequence_[z][s].clear();
			if ((s&0x01)==0)
			{
				for (uint8_t n=STARTNOTE;n<(STARTNOTE+16);++n)
				{
					m.setHeader(AtxMsg::AMH_NOTEON);
					//m.setMsgByte(1,MidiMsg::MCMD_NOTEON | c);
					uint8_t note = ((z+2)*12) + n;
					m.setMidiData(0,note);
					m.setMidiData(1,127);
					m.setClkStamp(t);
					sequence_[z][s].append(m);
					m.setHeader(AtxMsg::AMH_NOTEOFF);
					//m.setMsgByte(1,MidiMsg::MCMD_NOTEOFF | c);
					m.setMidiData(0,note);
					m.setMidiData(1,0);
					t += (3*(z+1));
					m.setClkStamp(t-1);
					sequence_[z][s].append(m);
					
				}
			}
			else
			{
				for (uint8_t n=(STARTNOTE+16);n>STARTNOTE;--n)
				{
					m.setHeader(AtxMsg::AMH_NOTEON);
					//m.setMidiData(1,MidiMsg::MCMD_NOTEON | c);
					uint8_t note = ((z+2)*12) + n;
					m.setMidiData(0,note);
					m.setMidiData(1,127);
					m.setClkStamp(t);
					sequence_[z][s].append(m);
					m.setHeader(AtxMsg::AMH_NOTEOFF);
					//m.setMsgByte(1,MidiMsg::MCMD_NOTEOFF | c);
					m.setMidiData(0,note);
					m.setMidiData(1,0);
					t += (3*(z+1));
					m.setClkStamp(t-1);
					sequence_[z][s].append(m);
				}
			}
			char name[AtxSeqMsgList::NAME_LEN] = "Zne Seq ";
			name[3] = z + 49;
			name[7] = s + 49;
			//sequence_[z][s].setName(name);
			sequence_[z][s].looping = true;
			int freeMem = FreeStack();
			int size = sizeof(sequence_[z][s]);
		}
	}
	initSeqBuffer();
}

void AtxCSequencer::setBpm(uint16_t newValue)
{
	if (newValue<20)
	{
		newValue = 20;
	}
	else if(newValue>300)
	{
		newValue = 300;
	}
	bpm_ = newValue;
	base_->sequencerBpmChanged(bpm_);
}

uint8_t AtxCSequencer::getEventListIndex(uint_fast8_t zone)
{
	return editIndex_[zone][editSeq_[zone]];
}

void AtxCSequencer::setSequenceName(uint_fast8_t zone, uint_fast8_t seq, char * newName)
{
	sequence_[zone][seq].setName(newName);
	refreshOverviewName(zone,seq,calcDisplay(zone),calcRow(zone,seq));
}

void AtxCSequencer::setSequenceBars(uint_fast8_t zone, uint_fast8_t seq, uint16_t newBars)
{
	sequence_[zone][seq].setLength(getClksPerBar(zone,seq) * newBars);
	if (isOverviewMode())
	{
		refreshOverviewName(zone,seq,calcDisplay(zone),calcRow(zone,seq));
	}
}

void AtxCSequencer::toggleCue()
{
	using namespace Atx;
	if (sequence_[editZone_][editSeq_[editZone_]].playState==AtxSeqMsgList::PS_STOP)
	{
		setPlayState(editZone_,editSeq_[editZone_],AtxSeqMsgList::PS_CUE);
	}
	else
	{
		setPlayState(editZone_,editSeq_[editZone_],AtxSeqMsgList::PS_STOP);
	}
}

void AtxCSequencer::toggleLoop()
{
	setLoop(editZone_,editSeq_[editZone_],!sequence_[editZone_][editSeq_[editZone_]].looping);
}

void AtxCSequencer::pollClk(uint16_t clksPassed)
{
	using namespace Atx;
	if (seqPlayMode_==SPM_STOP)
	{
		return;
	}
	while(clksPassed)
	{
		clksPassed--;
		if (clk_ % clksPerBar_==0)  //new bar
		{
			//AtxMsg m;  //NO THIS ISN@T THE WAY TO MCMD_SPP
			//m.setHeader(AtxMsg::AMH_COMMON3);
			//m.setMsgByte(1,MidiMsg::MCMD_SPP);
			//uint32_t beats = clk_ / 6;
			//m.setMsgByte(2,beats & 0x7F);
			//m.setMsgByte(3,(beats >> 7) & 0x7F);
			//base_->sequencerTxCard(I2C_GENERAL_CALL,&m);
			for (uint_fast8_t i=0;i<MAX_ZONES;++i)
			{
				for (uint_fast8_t j=0;j<MAX_SEQS;++j)
				{
					if (sequence_[i][j].playState==AtxSeqMsgList::PS_CUE)
					{
						if (seqPlayMode_==SPM_REC && i==editZone_)
						{
							seqBuffer_.reset();
							seqBuffer_.playState = AtxSeqMsgList::PS_REC;
							setPlayState(i,j,AtxSeqMsgList::PS_REC);
						}
						else
						{
							setPlayState(i,j,AtxSeqMsgList::PS_PLAY);
						}
					}
				}

			}
		}
		if (seqPlayMode_==SPM_REC)
		{
			if (clk_ % clksPerBeat_==0)  //new beat
			{
				AtxMsg m;
				m.setHeader(AtxMsg::AMH_NOTEON);
				m.setMidiCard(clickCard_);
				m.setMidiData(0,clickNote_);
				m.setMidiData(1,127);
				base_->sequencerTxCard(clickCard_,&m);
				clickOffClk_ = clk_ + (clksPerBeat_ >> 2);
			}
			else if(clk_==clickOffClk_)
			{
				AtxMsg m;
				m.setHeader(AtxMsg::AMH_NOTEOFF);
				m.setMidiCard(clickCard_);
				m.setMidiData(0,clickNote_);
				base_->sequencerTxCard(clickCard_,&m);
			}
		}

		for (uint_fast8_t i=0;i<MAX_ZONES;++i)
		{
			AtxSeqMsgList * seqTiming = &sequence_[i][playSeq_[i]];
			AtxSeqMsgList * seqNotes;
			if ((sequence_[i][playSeq_[i]].playState==AtxSeqMsgList::PS_REC) && i==editZone_)
			{
				seqNotes = &seqBuffer_;
			}
			else
			{
				seqNotes = &sequence_[i][playSeq_[i]];
			}
			if (seqTiming->playState==AtxSeqMsgList::PS_PLAY)
			{
				seqNotes->clk = seqTiming->clk;
				while (seqNotes->isMsgAtClk())
				{
					base_->sequencerTxZone(i,&seqNotes->getPlayMsg());
					if (!seqNotes->incIndex())
					{
						seqNotes->setIndex(0);
						break;
					}
				}
				seqTiming->clk++;
				if (seqTiming->clk>=seqTiming->getLength())
				{
					if (seqTiming->looping==false)
					{
						setPlayState(i,playSeq_[i],AtxSeqMsgList::PS_STOP);
					}
					else
					{
						sequence_[i][playSeq_[i]].reset();
					}
				}
			}
			

		}
		while (seqBuffer_.isMsgAtClk())
		{
			base_->sequencerTxZone(editZone_,&seqBuffer_.getPlayMsg());
			if (!seqBuffer_.incIndex())
			{
				seqBuffer_.setIndex(0);
				break;
			}
		}
		seqBuffer_.clk++;
		if (seqBuffer_.clk>=seqBuffer_.getLength())  //always loop
		{
			if (seqBuffer_.playState==AtxSeqMsgList::PS_REC && seqBuffer_.looping==true)
			{
				seqBuffer_.playState = AtxSeqMsgList::PS_PLAY;
				setPlayState(editZone_,playSeq_[editZone_],AtxSeqMsgList::PS_PLAY);
			}
			seqBuffer_.reset();
		}
		clk_++;
	}
}

void AtxCSequencer::setPlayState(uint_fast8_t zone, uint_fast8_t seq, AtxSeqMsgList::PlayState newState)
{
	sequence_[zone][seq].playState = newState;
	sequence_[zone][seq].reset();  //as far as I can tell, all changes in state require reset
	switch(newState)
	{
		case AtxSeqMsgList::PS_STOP:
		zone_[zone]->allNotesOff(); //stop any playing note
		break;
		case AtxSeqMsgList::PS_CUE:
		for (uint_fast8_t i=0;i<MAX_SEQS;++i)
		{
			if (i!=seq && sequence_[zone][i].playState==AtxSeqMsgList::PS_CUE)
			{
				setPlayState(zone,i,AtxSeqMsgList::PS_STOP);
			}
		}
		break;
		case AtxSeqMsgList::PS_PLAY:
		case AtxSeqMsgList::PS_REC:
		playSeq_[zone] = seq; //still playseq even tho rec
		for (uint_fast8_t i=0;i<MAX_SEQS;++i)
		{
			if (i!=seq && sequence_[zone][i].playState==AtxSeqMsgList::PS_PLAY)
			{
				setPlayState(zone,i,AtxSeqMsgList::PS_STOP);
			}
		}
		if (newState==AtxSeqMsgList::PS_REC)
		{
			zone_[zone]->allNotesOff(); //stop any playing note
			initSeqBuffer();
		}
		break;
	}
	
	if (isOverviewMode() && isOverviewSeqVisible(zone,seq))
	{
		base_->sequencerOvPlayChanged(zone,seq,(isSelected(zone) & seq==editSeq_[zone]),newState,calcDisplay(zone),calcRow(zone,seq));
	}
}


void AtxCSequencer::setLoop(uint_fast8_t zone, uint_fast8_t seq, bool newLoop)
{
	sequence_[zone][seq].looping = newLoop;
	if (isOverviewMode() && isOverviewSeqVisible(zone,seq))
	{
		base_->sequencerOvSeqLoopChanged(zone,seq,sequence_[zone][seq].looping,calcDisplay(zone),calcRow(zone,seq));
	}
}

void AtxCSequencer::setEditSeq(uint_fast8_t zone, uint8_t newSeq)
{
	editSeq_[zone] = newSeq;
	if (isOverviewMode())
	{
		refreshOverviewZone(zone);  //need to update whole zone, because scrolling up/down
	}
}

void AtxCSequencer::pollOv()
{
	using namespace Atx;
	static uint32_t lastClk = 0;
	static uint8_t lastPos[MAX_ZONES][MAX_SEQS] = {{0}};
	if (isOverviewMode())
	{
		for (uint_fast8_t z=0;z<MAX_ZONES;++z)
		{
			for (uint_fast8_t s=0;s<MAX_SEQS;++s)
			{
				if (isOverviewSeqVisible(z,s) && sequence_[z][s].getLength())
				{
					uint8_t newPos = calcPos(z,s);
					if (newPos!=lastPos[z][s])
					{
						lastPos[z][s] = newPos;
						base_->sequencerOvSeqPosChanged(z,s,newPos,calcDisplay(z),calcRow(z,s));
					}
				}
			}
		}
	}
	if(seqMode_==S_OVERVIEW)
	{
		if (clk_!=lastClk)
		{
			lastClk = clk_;
			base_->sequencerOvClkChanged(calcBar(clk_),calcBeat(clk_),calcClk(clk_));
		}
	}
}


void AtxCSequencer::setPlayMode(SeqPlayMode newMode)
{
	using namespace Atx;
	switch(newMode)
	{
		case SPM_STOP:
		if(clickOffClk_>clk_)  //stop metronome
		{
			AtxMsg m;
			m.setHeader(AtxMsg::AMH_NOTEOFF);
			m.setMidiCard(clickCard_);
			m.setMidiData(0,clickNote_);
			base_->sequencerTxCard(clickCard_,&m);
		}
		for (uint_fast8_t i=0;i<MAX_ZONES;++i)
		{
			setPlayState(i,playSeq_[i],AtxSeqMsgList::PS_STOP);
		}
		seqBuffer_.playState = AtxSeqMsgList::PS_STOP;
		break;
		case SPM_PLAY:
		if (seqPlayMode_==SPM_STOP)
		{
			clk_ = 0;
			seqBuffer_.reset();
		}
		seqBuffer_.playState = AtxSeqMsgList::PS_PLAY;
		for (uint_fast8_t i=0;i<MAX_ZONES;++i)
		{
			for (uint_fast8_t j=0;j<MAX_SEQS;++j)
			{
				if (seqPlayMode_==SPM_STOP)
				{
					sequence_[i][j].reset();
				}
				if (sequence_[i][j].playState==AtxSeqMsgList::PS_CUE)
				{
					setPlayState(i,j,AtxSeqMsgList::PS_PLAY);
				}
			}
		}
		break;
		case SPM_REC:
		if (seqPlayMode_==SPM_STOP)
		{
			clk_ = 0;
			//seqBuffer_.reset();
		}
		//seqBuffer_.playState = AtxSeqMsgList::PS_PLAY;
		for (uint_fast8_t i=0;i<MAX_ZONES;++i)
		{
			for (uint_fast8_t j=0;j<MAX_SEQS;++j)
			{
				if (seqPlayMode_==SPM_STOP)
				{
					sequence_[i][j].reset();
				}
				if (sequence_[i][j].playState==AtxSeqMsgList::PS_CUE)
				{
					if (i==editZone_)
					{
						setPlayState(i,j,AtxSeqMsgList::PS_REC);
					}
					else
					{
						setPlayState(i,j,AtxSeqMsgList::PS_PLAY);
					}
				}
			}
		}
		break;
	}
	seqPlayMode_ = newMode;
	AtxMsg m;
	if (seqPlayMode_==AtxCSequencer::SPM_STOP)
	{
		m.setHeader(AtxMsg::AMH_REALTIMEBYTE);
		m.setMidiCmd(MidiMsg::MCMD_STOP);
		base_->sequencerTxCard(I2C_GENERAL_CALL,&m);
		//delay(1);  //eek remove!
	}
	else
	{
		m.setHeader(AtxMsg::AMH_REALTIMEBYTE);
		m.setMidiCmd(MidiMsg::MCMD_START);
		base_->sequencerTxCard(I2C_GENERAL_CALL,&m);
	}
	base_->sequencerPlayChanged((uint8_t)seqPlayMode_);
}


bool AtxCSequencer::isSelected(uint_fast8_t zone)
{
	return (zone==editZone_);
}

void AtxCSequencer::remapMidiToSequence(char * fileName)
{
	using namespace Atx;
	uint8_t ppqnRatio = midiList_.getClksPerQuarterNote() / CLKS_PER_QUARTER_NOTE;
	sequence_[editZone_][editSeq_[editZone_]].clear();
	uint32_t ts = 0;
	for (uint_fast16_t i=0;i<midiList_.getCount();++i)
	{
		uint8_t cmd,ch,n,v;
		AtxSeqMsg m;
		cmd = midiList_.getEvent(i).getCommand() & 0xF0;
		//ch = midiList_.getEvent(i).getCommand() & 0x0F;
		n = midiList_.getEvent(i).getData1();
		v = midiList_.getEvent(i).getData2();
		if (cmd==MidiMsg::MCMD_NOTEON && v==0)
		{
			cmd = MidiMsg::MCMD_NOTEOFF;
		}
		ts += midiList_.getEvent(i).getDeltaTime();
		switch (cmd)
		{
			case MidiMsg::MCMD_NOTEON:
			{
				m.setHeader(AtxMsg::AMH_NOTEON);
				//m.setMsgByte(1,(MidiMsg::MCMD_NOTEON | editZone_));  //no point setting that here
				m.setMidiData(0,n);
				m.setMidiData(1,v);
				m.setClkStamp(ts / ppqnRatio);
				sequence_[editZone_][editSeq_[editZone_]].append(m);
			}
			break;
			case MidiMsg::MCMD_NOTEOFF:
			{
				m.setHeader(AtxMsg::AMH_NOTEOFF);
				//m.setMsgByte(1,(MidiMsg::MCMD_NOTEOFF | editZone_));  //no point setting that here
				m.setMidiData(0,n);
				m.setClkStamp(ts / ppqnRatio);
				sequence_[editZone_][editSeq_[editZone_]].append(m);
			}
			break;
		}
	}
	setSequenceName(editZone_,editSeq_[editZone_],fileName);
	//sequence_[editZone_][editSeq_[editZone_]].setName(fileName,8);
	//base_->sequencerOvSeqNameChanged(editZone_,1,sequence_[editZone_][editSeq_[editZone_]].getNamePtr(),calcDisplay(editZone_),calcRow(editZone_,editSeq_[editZone_]));
}

//YOU NEED TO COME BACK TO THIS TO CHECK IT
void AtxCSequencer::remapMpeToSequence()
{
	//using namespace Atx;
	//uint8_t cmd, ch;
	//uint16_t chInUse = 0;
	//for (uint16_t i=0;i<midiList_.getCount();++i)
	//{
	//cmd = midiList_.getEvent(i).getCommand() & 0xF0;
	//ch = midiList_.getEvent(i).getCommand() & 0x0F;
	//if (cmd<0xF0)  //ignore sys common msgs
	//{
	//bitSet(chInUse,ch);
	//}
	//}
	//uint16_t chToVoiceMap[16];
	//uint8_t v = 0;
	//for (uint8_t i = 0;i<16;++i)
	//{
	//chToVoiceMap[i] = UNUSED;
	//if (bitRead(chInUse,i)==true)
	//{
	//while (card_[v]->zone!=card_[editZone_]->zone)
	//{
	//v++;
	//v &= 0x07;
	//}
	//chToVoiceMap[i] = v;
	//v++;
	//v &= 0x07;
	//}
	//}
	//for (uint8_t i=0;i<MAX_SYNTHCARDS;++i)
	//{
	//if (card_[i]->zone==card_[editZone_]->zone)
	//{
	//sequence_[i][1-actSeq_[i]].clear();
	//}
	//}
	//uint16_t ts = 0;
	//for (uint_fast16_t i=0;i<midiList_.getCount();++i)
	//{
	//cmd = midiList_.getEvent(i).getCommand() & 0xF0;
	//ch = midiList_.getEvent(i).getCommand() & 0x0F;
	//switch (cmd)
	//{
	//case MidiMsg::MCMD_NOTEON:
	//case MidiMsg::MCMD_NOTEOFF:
	//{
	//AtxMsg m;
	//if (cmd==MidiMsg::MCMD_NOTEON)
	//{
	//m.setHeader(AtxMsg::AMH_NOTEON);
	//m.setMsgByte(1,MidiMsg::MCMD_NOTEON | chToVoiceMap[ch]);
	//}
	//else
	//{
	//m.setHeader(AtxMsg::AMH_NOTEOFF);
	//m.setMsgByte(1,MidiMsg::MCMD_NOTEOFF | chToVoiceMap[ch]);
	//}
	//
	//m.setMsgByte(2,midiList_.getEvent(i).getData1());
	//m.setMsgByte(3,midiList_.getEvent(i).getData2());
	//m.setClkStamp(ts);
	//sequence_[chToVoiceMap[ch]][1-actSeq_[chToVoiceMap[ch]]].append(m);
	//}
	//break;
	//}
	//ts += midiList_.getEvent(i).getDeltaTime();
	//}
}

void AtxCSequencer::setEditZone(uint8_t newZone)
{
	using namespace Atx;
	if (newZone<5 && isOverviewMode())
	{
		base_->sequencerOvPlayChanged(editZone_,editSeq_[editZone_],false,sequence_[editZone_][editSeq_[editZone_]].playState,calcDisplay(editZone_),calcRow(editZone_,editSeq_[editZone_]));
	}
	editZone_ = newZone;
	base_->sequencerEditZoneChanged(editZone_);
	if (newZone<5)
	{
		if (isOverviewMode())
		{
			base_->sequencerOvPlayChanged(editZone_,editSeq_[editZone_],true,sequence_[editZone_][editSeq_[editZone_]].playState,calcDisplay(editZone_),calcRow(editZone_,editSeq_[editZone_]));  //add sel to new seq
		}
	}
	else  //you'll need to refresh the whole page for the scrolling
	{
		refreshOverviewPage();
	}
}

bool AtxCSequencer::setEditZoneFromCtrl(uint8_t ctrl)
{
	uint8_t page = editZone_ / DISPLAY_COLS;
	uint8_t newZone = (page * DISPLAY_COLS)  + ctrl;
	if (newZone >= Atx::MAX_ZONES)
	{
		return false;
	}
	else
	{
		if (zone_[newZone]->getEnabled())
		{
			if (newZone!=editZone_)
			{
				setEditZone(newZone);
			}
			return true;
		}
		else
		{
			return false;
		}
	}
}

//uint8_t AtxCSequencer::calcPos(uint_fast8_t zone, uint_fast8_t index)  //play pos 0 = 0, otherwise 1 - 8
//{
//if (sequence_[zone][index].clk==0)
//{
//return 0;
//}
//else
//{
//return ((sequence_[zone][index].clk << 3) / sequence_[zone][index].getLength())+1;
//}
//}

uint8_t AtxCSequencer::calcPos(uint_fast8_t zone, uint_fast8_t index)  //play pos 0 - 63
{
	if (sequence_[zone][index].getLength()==0)
	{
		return 0;
	}
	else
	{
		return (((uint32_t)sequence_[zone][index].clk << 6) / sequence_[zone][index].getLength());
	}
}

void AtxCSequencer::setSeqMode(SeqMode newMode)
{
	seqMode_ = newMode;
	base_->sequencerModeChanged(seqMode_);
	using namespace Atx;
	switch(seqMode_)
	{
		case S_OVERVIEW:
		base_->sequencerOvClkChanged(calcBar(clk_),calcBeat(clk_),calcClk(clk_));
		break;
	}
	if (isOverviewMode())
	{
		refreshOverviewPage();
	}
	else
	{
		if (seqPlayMode_==SPM_REC)
		{
			setPlayMode(SPM_PLAY);
		}
		for (uint_fast8_t i=0;i<DISPLAY_COLS;++i)
		{
			base_->sequencerDisplayOnMapChanged(0xFF);
		}
	}
}

void AtxCSequencer::refreshOverviewPage()
{
	uint8_t f, l;
	uint8_t o = 0, onMap = 0b11000000;
	if (editZone_<6)
	{
		f = 0;
		l = 6;
	}
	else
	{
		f = editZone_ - 5;
		l = editZone_ + 1;
	}
	for (uint_fast8_t i=0;i<MAX_SEQS;++i)
	{
		seqOverviewVisible_[i] = 0;
	}
	for (uint_fast8_t i=f;i<l;++i)
	{
		if(i<Atx::MAX_ZONES)
		{
			if (zone_[i]->getEnabled())
			{
				refreshOverviewZone(i);
				bitSet(onMap,o);
			}
		}
		else
		{
			break;
		}
		o++;
	}
	base_->sequencerDisplayOnMapChanged(onMap);
}

void AtxCSequencer::refreshOverviewZone(uint_fast8_t zone)
{
	if (zone_[zone]->getEnabled()==false)
	{
		return;
	}
	uint_fast8_t f,l;

	if (editSeq_[zone]>(MAX_SEQS-DISPLAY_ROWS))
	{
		f = MAX_SEQS - DISPLAY_ROWS;
		l = MAX_SEQS;
	}
	else
	{
		f = editSeq_[zone];
		l = editSeq_[zone] + DISPLAY_ROWS;
	}
	for (uint_fast8_t i=0;i<MAX_SEQS;++i)
	{
		if (i>f || i<l)
		{
			bitSet(seqOverviewVisible_[i],zone);
			refreshOverviewSeq(zone,i);
		}
		else
		{
			bitClear(seqOverviewVisible_[i],zone);
		}

	}
}

void AtxCSequencer::refreshOverviewSeq(uint_fast8_t zone, uint_fast8_t seq)
{
	uint8_t d = calcDisplay(zone);
	uint8_t r = calcRow(zone,seq);
	base_->sequencerOvSeqChanged(zone,seq,d,r);
	base_->sequencerOvPlayChanged(zone,seq,(zone==editZone_ && seq==editSeq_[zone]),sequence_[zone][seq].playState,d,r);
	base_->sequencerOvSeqLoopChanged(zone,seq,sequence_[zone][seq].looping,d,r);
	refreshOverviewName(zone,seq,d,r);
	base_->sequencerOvSeqPosChanged(zone,seq,calcPos(zone,seq),d,r);
}

void AtxCSequencer::refreshOverviewName(uint_fast8_t zone, uint_fast8_t seq, uint_fast8_t display, uint_fast8_t row)
{
	if(seqMode_==S_LENGTH)
	{
		char name[9];
		uint16_t l = sequence_[zone][seq].getLength();
		uint16_t bars = l / getClksPerBar();
		if (bars==1)
		{
			snprintf(name, 9, "%d bar", bars);
		}
		else
		{
			snprintf(name, 9, "%d bars", bars);
		}
		base_->sequencerOvSeqNameChanged(zone,seq,name,display,row);
	}
	else
	{
		base_->sequencerOvSeqNameChanged(zone,seq,sequence_[zone][seq].getNamePtr(),display,row);
	}
}

void AtxCSequencer::setSeqBufferMode(SeqBufferMode newMode)
{
	seqBufferMode_ = newMode;
	
	base_->sequencerBufferModeChanged(seqBufferMode_);
}

void AtxCSequencer::appendSeqBuffer(AtxSeqMsg * msg)
{
	if (seqBuffer_.playState==AtxSeqMsgList::PS_REC)
	{
		msg->setClkStamp(seqBuffer_.clk);
		seqBuffer_.append(*msg);
	}
}

void AtxCSequencer::setEventListIndex(uint_fast8_t zone, uint16_t newIndex)
{
	editIndex_[zone][editSeq_[zone]] = newIndex;
	base_->sequencerEventListChanged(newIndex,&sequence_[zone][editSeq_[zone]].getMsg(editIndex_[zone][editSeq_[zone]]));
}

uint16_t AtxCSequencer::calcBar(uint32_t clkStamp)
{
	return (clkStamp / getClksPerBar()) + 1;
}

uint8_t AtxCSequencer::calcBeat(uint32_t clkStamp)
{
	return ((clkStamp % getClksPerBar()) / getClksPerBeat()) + 1;
}

uint8_t AtxCSequencer::calcClk(uint32_t clkStamp)
{
	return clkStamp % getClksPerBeat();
}

//void AtxCSequencer::initSeqAdd()
void AtxCSequencer::initSeqBuffer()
{
	seqBuffer_.clear();  //surely always clear first?
	if(isOverviewMode())  //the rec buffer
	{
		seqBuffer_.setBeatsPerBar(sequence_[editZone_][playSeq_[editZone_]].getBeatsPerBar());
		seqBuffer_.setClksPerBeat(sequence_[editZone_][playSeq_[editZone_]].getClksPerBeat());
		seqBuffer_.setLength(sequence_[editZone_][playSeq_[editZone_]].getLength());
	}
}

