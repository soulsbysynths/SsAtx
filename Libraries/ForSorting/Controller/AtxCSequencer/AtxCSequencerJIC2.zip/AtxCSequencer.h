/*
* AtxCSequencer.h
*
* Created: 14/06/2018 11:35:00
* Author: info
*/


#ifndef __ATXCSEQUENCER_H__
#define __ATXCSEQUENCER_H__
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <vector>
#include "Atx.h"
#include "AtxCSequencerBase.h"
#include "AtxSeqMsgList.h"
#include "MidiMsgList.h"
#include "AtxCard.h"
#include "AtxZone.h"
#include "AtxCSequencerProgmem.h"
#include "AtxParamList.h"
#include "SsHelpers.h"
#include "FreeStack.h"

#ifndef bitRead
#define bitRead(value, bit) (((value) >> (bit)) & 0x01)
#endif
#ifndef bitSet
#define bitSet(value, bit) ((value) |= (1UL << (bit)))
#endif
#ifndef bitClear
#define bitClear(value, bit) ((value) &= ~(1UL << (bit)))
#endif
#ifndef bitWrite
#define bitWrite(value, bit, bitvalue) (bitvalue ? bitSet(value, bit) : bitClear(value, bit))
#endif

class AtxCSequencer
{
	//variables
	public:
	enum SeqMode : uint8_t
	{
		S_OVERVIEW = 0,
		S_LENGTH = 1,
		S_IMPORTMIDI = 2,
		S_LOADSEQ = 3,
		S_SAVESEQ = 4,
		S_MAX
	};
	enum SeqPlayMode : uint8_t
	{
		SPM_STOP = 0,
		SPM_PLAY,
		SPM_REC
	};
	enum SeqBufferMode: uint8_t
	{
		SBM_IDLE = 0,
		SBM_CHANGED,
		SBM_REVIEW,
		SMB_BOUNCE	
	};
	const static uint8_t MAX_SEQS_BS = 3;
	const static uint8_t MAX_SEQS = 1 << MAX_SEQS_BS;
	static const uint8_t CLKS_PER_QUARTER_NOTE = 24;
	static const uint8_t DISPLAY_COLS = 6;
	static const uint8_t DISPLAY_ROWS = 2;
	const static uint8_t STP_TYPE_INDEX = 6;
	protected:
	private:
	const static uint16_t SEQ_MODE_OVERVIEW = 0b0000000000011111;
	static const int8_t I2C_GENERAL_CALL = -8;
	AtxCSequencerBase* base_;
	AtxZone * zone_[Atx::MAX_ZONES];
	SeqMode seqMode_ = S_OVERVIEW;
	uint8_t seqModeIndex_ = 0;	//used for accessing zero aligned arrays for AddTrans
	AtxSeqMsgList sequence_[Atx::MAX_ZONES][MAX_SEQS];
	AtxSeqMsgList seqBuffer_;
	SeqBufferMode seqBufferMode_ = SBM_IDLE;
	uint8_t seqOverviewVisible_[MAX_SEQS] = {0};  //uint8_t for 8 MAX_ZONES
	MidiMsgList midiList_;
	uint16_t editIndex_[Atx::MAX_ZONES][MAX_SEQS] = {{0}};
	uint8_t editZone_ = 0;	//all these don't need to be stored in a patch
	uint8_t editFunc_[Atx::MAX_ZONES] = {0};
	uint8_t editSeq_[Atx::MAX_ZONES] = {0};
	uint8_t playSeq_[Atx::MAX_ZONES] = {0};	
	uint16_t bpm_ = 120;
	uint32_t clk_ = 0;
	uint8_t clksPerBeat_ = CLKS_PER_QUARTER_NOTE;  //for the sequencer, not the sequence
	uint8_t beatsPerBar_ = 4;  //for the sequencer, not the sequence
	uint8_t clksPerBar_ = clksPerBeat_ * beatsPerBar_;  //for sequencer.  Must keep this synced.
	SeqPlayMode seqPlayMode_ = SPM_STOP;
	uint8_t clickCard_ = 7;
	uint8_t clickNote_ = 37;
	uint32_t clickOffClk_ = 0;
	AtxParamList paramList_;
	//functions
	public:
	static AtxCSequencer& getInstance()
	{
		static AtxCSequencer instance; // Guaranteed to be destroyed.
		return instance;  // Instantiated on first use.
	}
	AtxCSequencer(AtxCSequencer const&) = delete;
	void operator=(AtxCSequencer const&) = delete;
	void pollClk(uint16_t clksPassed);
	void pollOv();
	void initialize();
	//void construct(AtxCSequencerBase* base, AtxCard* cardPtrs[]);
	void construct(AtxCSequencerBase* base, AtxZone* zonePtrs[]);
	void setSeqMode(SeqMode newMode);
	SeqMode getSeqMode(){return seqMode_;}
	MidiMsgList& getMidiList() { return midiList_; }
	const MidiMsgList& getMidiList() const { return midiList_; }
	AtxSeqMsgList& getSequence(uint_fast8_t zone, uint_fast8_t seq){return sequence_[zone][seq];}
	const AtxSeqMsgList& getSequence(uint_fast8_t zone, uint_fast8_t seq) const {return sequence_[zone][seq];}
	AtxSeqMsgList& getSequence(uint_fast8_t zone){return sequence_[zone][editSeq_[editZone_]];}
	const AtxSeqMsgList& getSequence(uint_fast8_t zone) const {return sequence_[zone][editSeq_[editZone_]];}
	AtxSeqMsgList& getSequence(){return getSequence(editZone_);}
	const AtxSeqMsgList& getSequence() const {return getSequence(editZone_);}
	void setEditZone(uint8_t newZone);
	uint8_t getEditZone(){return editZone_;}
	bool setEditZoneFromCtrl(uint8_t ctrl);  //return if valid/visible zone
	void setEditSeq(uint_fast8_t zone, uint8_t newSeq);
	void setEditSeq(uint8_t newSeq){setEditSeq(editZone_,newSeq);}
	uint8_t getEditSeq(uint_fast8_t zone){return editSeq_[zone];}
	uint8_t getEditSeq(){return editSeq_[editZone_];}
	void setEventListIndex(uint_fast8_t zone, uint16_t newIndex);
	void setEventListIndex(uint16_t newIndex){setEventListIndex(editZone_,newIndex);}
	uint8_t getEventListIndex(uint_fast8_t zone);
	uint8_t getEventListIndex(){return getEventListIndex(editZone_);}
	uint8_t getClksPerBar(uint_fast8_t zone, uint_fast8_t seq){return sequence_[zone][seq].getClksPerBeat() * sequence_[zone][seq].getBeatsPerBar();}
	uint8_t getClksPerBar(uint_fast8_t zone){return getClksPerBar(zone,editSeq_[zone]);}
	uint8_t getClksPerBar(){return getClksPerBar(editZone_);}
	uint8_t getClksPerBeat(uint_fast8_t zone, uint_fast8_t seq){return sequence_[zone][seq].getClksPerBeat();}
	uint8_t getClksPerBeat(uint_fast8_t zone){return getClksPerBeat(zone,editSeq_[zone]);}
	uint8_t getClksPerBeat(){return getClksPerBeat(editZone_);}
	uint8_t getBeatsPerBar(uint_fast8_t zone, uint_fast8_t seq){return sequence_[zone][seq].getBeatsPerBar();}
	uint8_t getBeatsPerBar(uint_fast8_t zone){return getBeatsPerBar(zone,editSeq_[zone]);}
	uint8_t getBeatsPerBar(){return getBeatsPerBar(editZone_);}
	uint16_t getSequenceCount(uint_fast8_t zone, uint_fast8_t seq){return sequence_[zone][seq].getCount();}
	uint16_t getSequenceCount(uint_fast8_t zone){return getSequenceCount(zone,editSeq_[zone]);}
	uint16_t getSequenceCount(){return getSequenceCount(editZone_);}
	void setSequenceName(uint_fast8_t zone, uint_fast8_t seq, char * newName);
	void setSequenceName(uint_fast8_t zone, char * newName, size_t len){setSequenceName(zone,editSeq_[zone],newName);}
	void setSequenceBars(uint_fast8_t zone, uint_fast8_t seq, uint16_t newBars);
	void setSequenceBars(uint16_t newBars){setSequenceBars(editZone_,editSeq_[editZone_],newBars);}
	void setBpm(uint16_t newValue);
	uint16_t getBpm(){return bpm_;}
	AtxSeqMsgList::PlayState getPlayState(uint_fast8_t zone, uint_fast8_t seq){return sequence_[zone][seq].playState;}
	AtxSeqMsgList::PlayState getPlayState(uint_fast8_t zone){return getPlayState(zone,editSeq_[zone]);}
	AtxSeqMsgList::PlayState getPlayState(){return getPlayState(editZone_);}
	void setPlayState(uint_fast8_t zone, uint_fast8_t seq, AtxSeqMsgList::PlayState newState);
	void setPlayState(uint_fast8_t seq, AtxSeqMsgList::PlayState newState){setPlayState(editZone_,newState);}
	void setPlayState(AtxSeqMsgList::PlayState newState){setPlayState(editZone_,newState);}
	void setLoop(uint_fast8_t zone, uint_fast8_t seq, bool newLoop);
	void setLoop(uint_fast8_t zone, bool newLoop){setLoop(zone,editSeq_[zone],newLoop);}
	void setLoop(bool newLoop){setLoop(editZone_,newLoop);}
	void setPlayMode(SeqPlayMode newMode);
	SeqPlayMode getPlayMode(){return seqPlayMode_;}
	SeqBufferMode getSeqBufferMode(){return seqBufferMode_;}
	void setSeqBufferMode(SeqBufferMode newMode);
	void appendSeqBuffer(AtxSeqMsg * msg);
	uint16_t calcBar(uint32_t clkStamp);
	uint8_t calcBeat(uint32_t clkStamp);
	uint8_t calcClk(uint32_t clkStamp);
	uint8_t calcPos(uint_fast8_t zone, uint_fast8_t index);
	bool isSelected(uint_fast8_t zone);
	void remapMpeToSequence();
	void remapMidiToSequence(char * fileName);
	void toggleCue();
	void toggleLoop();
	void initSeqBuffer();
	bool isOverviewMode(){return bitRead(SEQ_MODE_OVERVIEW,(uint8_t)seqMode_);}
	bool isOverviewSeqVisible(uint_fast8_t zone, uint_fast8_t seq){return bitRead(seqOverviewVisible_[seq],zone);}
	
	protected:
	private:
	AtxCSequencer() {}
	//AtxCSequencer(AtxCSequencerBase* base, AtxCard* cardPtrs[]);
	AtxCSequencer(AtxCSequencerBase* base, AtxZone* zonePtrs[]);
	~AtxCSequencer();
	//AtxCSequencer( const AtxCSequencer &c );
	//AtxCSequencer& operator=( const AtxCSequencer &c );
	//void toggleActSeq(uint_fast8_t zone);
	//void toggleActSeq(){toggleActSeq(editZone_);}
	void refreshOverviewPage();
	void refreshOverviewZone(uint_fast8_t zone);
	void refreshOverviewSeq(uint_fast8_t zone, uint_fast8_t seq);
	void refreshOverviewName(uint_fast8_t zone, uint_fast8_t seq, uint_fast8_t display, uint_fast8_t row);
	uint8_t calcDisplay(uint_fast8_t zone){return (editZone_ > 5 ? (zone - (editZone_-5)) : zone);}
	uint8_t calcRow(uint_fast8_t zone, uint_fast8_t seq){return ((editSeq_[zone]>(MAX_SEQS-DISPLAY_ROWS)) ? (seq + DISPLAY_ROWS - MAX_SEQS) : (seq - editSeq_[zone]));}
}; //AtxCSequencer

#endif //__ATXCSEQUENCER_H__

