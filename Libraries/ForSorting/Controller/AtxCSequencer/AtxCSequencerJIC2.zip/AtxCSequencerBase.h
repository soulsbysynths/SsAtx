/*
 * AtxCSequencerBase.h
 *
 * Created: 14/06/2018 11:38:31
 *  Author: info
 */ 


#ifndef ATXCSEQUENCERBASE_H_
#define ATXCSEQUENCERBASE_H_

#include "AtxMsg.h"
#include "AtxMsgList.h"

class AtxCSequencerBase
{
	public:
	virtual void sequencerEditZoneChanged(uint_fast8_t zone) = 0;
	virtual void sequencerModeChanged(uint8_t seqMode) = 0;
	virtual void sequencerEventListChanged(uint_fast16_t index, AtxSeqMsg * msg) = 0;
	virtual void sequencerBpmChanged(uint_fast16_t bpm) = 0;
	virtual void sequencerTxCard(uint_fast8_t card, AtxMsg * msg) = 0;
	virtual void sequencerTxZone(uint_fast8_t zone, AtxMsg * msg) = 0;
	virtual void sequencerPlayChanged(uint8_t playMode) = 0;
	virtual void sequencerOvPlayChanged(uint_fast8_t zone, uint_fast8_t seq, bool selected, uint8_t playState, uint_fast8_t display, uint_fast8_t row) = 0;
	virtual void sequencerOvSeqChanged(uint_fast8_t zone, uint_fast8_t seq, uint_fast8_t display, uint_fast8_t row) = 0;
	virtual void sequencerOvSeqNameChanged(uint_fast8_t zone, uint_fast8_t seq, const char * name, uint_fast8_t display, uint_fast8_t row) = 0;
	virtual void sequencerOvSeqPosChanged(uint_fast8_t zone, uint_fast8_t seq, uint8_t pos, uint_fast8_t display, uint_fast8_t row) = 0;
	virtual void sequencerOvSeqLoopChanged(uint_fast8_t zone, uint_fast8_t seq, bool looping, uint_fast8_t display, uint_fast8_t row) = 0;
	virtual void sequencerOvClkChanged(uint16_t bar, uint8_t beat, uint8_t clk) = 0;
	virtual void sequencerDisplayOnMapChanged(uint8_t onMap) = 0;
	virtual void sequencerBufferModeChanged(uint8_t seqBufferMode) = 0;
    virtual void sequencerMemoryFree(int freeMem) = 0;
};




#endif /* ATXCSEQUENCERBASE_H_ */