/*
* AtxCSettings.cpp
*
* Created: 18/01/2018 11:48:42
* Author: info
*/


#include "AtxCSettings.h"

// default constructor
AtxCSettings::AtxCSettings(AtxCSettingsBase* base, AtxZone* zonePtrs[])
{
	construct(base,zonePtrs);
} //AtxCSettings

// default destructor
AtxCSettings::~AtxCSettings()
{
	if (base_!=NULL)
	{
		delete base_;
	}
} //~AtxCSettings

void AtxCSettings::construct(AtxCSettingsBase* base, AtxZone* zonePtrs[])
{
	base_ = base;
	for (uint_fast8_t i=0;i<MAX_VOICES;++i)
	{
		zone_[i] = zonePtrs[i];
	}
}

void AtxCSettings::initialize(uint_fast8_t initVoices)
{
	//zoneLayout_.initFullRange(0,initVoices);
	//for (uint_fast8_t i = 0;i<initVoices;++i)
	//{
		//zoneLayout_.initFullRange(i,0);
	//}
	//for (uint_fast8_t i=0;i<initVoices;++i)
	//{
		//function_[S_ZONES] = i;
		//setParameterValue(PZ_MASTER_CARD,i);
		//setParameterValue(PZ_CARDS,1);
	//}
	
	//ATMULTI
	//function_[S_ZONES] = 0;
	//setParameterValue(PZ_MASTER_CARD,0);
	//setParameterValue(PZ_CARDS,1);
	//setParameterValue(PZ_FIRMWARE,AtxCard::FW_ATMEGATRON);
	//function_[S_ZONES] = 1;
	//setParameterValue(PZ_MASTER_CARD,1);
	//setParameterValue(PZ_CARDS,3);
	//setParameterValue(PZ_FIRMWARE,AtxCard::FW_ATMEGATRON);
	//function_[S_ZONES] = 2;
	//setParameterValue(PZ_MASTER_CARD,4);
	//setParameterValue(PZ_CARDS,1);
	//setParameterValue(PZ_FIRMWARE,AtxCard::FW_ATMEGADRUM);
	//function_[S_ZONES] = 3;
	//setParameterValue(PZ_MASTER_CARD,5);
	//setParameterValue(PZ_CARDS,1);
	//setParameterValue(PZ_FIRMWARE,AtxCard::FW_ATMEGADRUM);
	
	//ATMEGA
	function_[S_ZONES] = 0;
	setParameterValue(PZ_MASTER_CARD,0);
	setParameterValue(PZ_CARDS,1);
	setParameterValue(PZ_FIRMWARE,AtxCard::FW_ATMEGATRON);
	function_[S_ZONES] = 1;
	setParameterValue(PZ_MASTER_CARD,1);
	setParameterValue(PZ_CARDS,1);
	setParameterValue(PZ_FIRMWARE,AtxCard::FW_ATMEGATRON);
}

void AtxCSettings::setSetting(Setting newSetting)
{
	setting_ = newSetting;
	base_->settingSettingChanged(setting_);
	setFunction(function_[setting_]);//force through update
}

void AtxCSettings::setFunction(uint8_t newFunc)
{
	function_[setting_] = newFunc;
	base_->settingFunctionChanged(setting_,function_[setting_]);
	switch(setting_)
	{
		case S_ZONES:
		for(uint8_t i=0;i<PZ_MAX;++i)
		{
			base_->settingParameterValueChanged(setting_,i,getParameterValue(i));
		}
		break;
		case S_MIDI:
		for(uint8_t i=0;i<PM_MAX;++i)
		{
			base_->settingParameterValueChanged(setting_,i,getParameterValue(i));
		}		
		break;
		case S_SEQUENCER:
		for(uint8_t i=0;i<PS_MAX;++i)
		{
			base_->settingParameterValueChanged(setting_,i,getParameterValue(i));
		}
		break;
	}
}

void AtxCSettings::setParameterValue(uint_fast8_t parameter, int_fast16_t newValue)
{
	uint8_t  v = function_[setting_];
	switch (setting_)
	{
		case S_ZONES:
		switch(parameter)
		{
			case PZ_MASTER_CARD:
			zone_[v]->setMasterCard(newValue);
			break;
			case PZ_CARDS:
			zone_[v]->setCards(newValue);
			break;
			case PZ_MASTER_PBEND:
			zone_[v]->masterPitchbendRange = newValue;
			break;
			case PZ_PN_PBEND:
			zone_[v]->perNotePitchbendRange = newValue;
			break;
			case PZ_UPPER_NOTE:
			zone_[v]->upperNote = newValue;
			break;
			case PZ_LOWER_NOTE:
			zone_[v]->lowerNote = newValue;
			break;
			case PZ_FIRMWARE:
			zone_[v]->firmware = (AtxCard::Firmware)newValue;
			break;
		}
		break;
		case S_MIDI:
		switch(parameter)
		{
			case PM_FILTER:
			midiFilter_[v] = (MidiFilter)newValue;
		}
		break;
		case S_SEQUENCER:
		switch(parameter)
		{
			case PS_BPM:
			seqBpm_ = newValue;
			case PS_CTRL:
			seqCtrl_ = (SequencerCtrl)newValue;
		}
	}
	base_->settingParameterValueChanged(setting_,parameter,newValue);
}

int_fast16_t AtxCSettings::getParameterValue(uint_fast8_t setting, uint_fast8_t func, uint_fast8_t parameter)
{
	switch(setting)
	{
		case S_ZONES:
		switch(parameter)
		{
			case PZ_MASTER_CARD:
			return zone_[func]->getMasterCard();
			break;
			case PZ_CARDS:
			return zone_[func]->getCards();
			break;
			case PZ_MASTER_PBEND:
			return zone_[func]->masterPitchbendRange;
			break;
			case PZ_PN_PBEND:
			return zone_[func]->perNotePitchbendRange;
			break;
			case PZ_UPPER_NOTE:
			return zone_[func]->upperNote;
			break;
			case PZ_LOWER_NOTE:
			return zone_[func]->lowerNote;
			break;
			case PZ_FIRMWARE:
			return zone_[func]->firmware;
			break;
		}
		break;
		case S_MIDI:
		switch(parameter)
		{
			case PM_FILTER:
			return midiFilter_[func];
		}
		break;
		case S_SEQUENCER:
		switch(parameter)
		{
			case PS_BPM:
			return seqBpm_;
			case PS_CTRL:
			return seqCtrl_;
		}
		break;
	}
}