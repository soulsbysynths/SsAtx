/*
* AtxCSettings.h
*
* Created: 18/01/2018 11:48:42
* Author: info
*/


#ifndef __ATXCSETTINGS_H__
#define __ATXCSETTINGS_H__

#include <stdlib.h>
#include <stdint.h>
#include "AtxCSettingsBase.h"
#include "AtxZone.h"
//#include "MpeZoneLayout.h"

#define SETTINGS 16
#define FUNCTIONS 16

class AtxCSettings
{
	//variables
	public:
	enum Setting : uint8_t
	{
		S_ZONES = 0,
		S_MIDI,
		S_SEQUENCER,
		S_MAX
	};
	//enum ParamZone : uint8_t
	//{
	//PZ_MASTER_CHANNEL = 0,
	//PZ_NOTE_CHANNELS,
	//PZ_MASTER_PBEND,
	//PZ_PN_PBEND,
	//PZ_LOWER_NOTE,
	//PZ_UPPER_NOTE,
	//PZ_FIRMWARE,
	//PZ_ACTIVE,
	//PZ_MAX
	//};
	enum ParamZone : uint8_t
	{
		PZ_MASTER_CARD = 0,
		PZ_CARDS,
		PZ_MASTER_PBEND,
		PZ_PN_PBEND,
		PZ_LOWER_NOTE,
		PZ_UPPER_NOTE,
		PZ_FIRMWARE,
		PZ_MAX
	};
	enum ParamMidi: uint8_t
	{
		PM_0 = 0,
		PM_1,
		PM_2,
		PM_3,
		PM_4,
		PM_5,		
		PM_FILTER,
		PM_MAX
	};
	enum ParamSequencer: uint8_t
	{
		PS_BPM = 0,
		PS_1,
		PS_2,
		PS_3,
		PS_4,
		PS_5,
		PS_CTRL,
		PS_MAX
	};

	enum SequencerCtrl : uint8_t
	{
		SC_INT = 0,
		SC_EXT = 1	
	};
	enum MidiFilter : uint8_t
	{
		MF_NONE = 0,
		MF_CHANNEL,
		MF_COMMON,
		MF_ALL
		};
	static const uint8_t MAX_VOICES = 8;
	static const uint8_t ENC_PARAM = 6;
	protected:
	private:
	AtxCSettingsBase* base_;
	Setting setting_ = S_ZONES;
	uint8_t function_[SETTINGS] = {0};
	AtxZone * zone_[MAX_VOICES];  //pointers to the zones
	MidiFilter midiFilter_[MAX_VOICES];
	uint16_t seqBpm_ = 120;
	SequencerCtrl seqCtrl_ = SC_INT;
	//MpeZoneLayout zoneLayout_;
	//functions
	public:
	static AtxCSettings& getInstance()
	{
		static AtxCSettings instance; // Guaranteed to be destroyed.
		return instance;  // Instantiated on first use.
	}
	void construct(AtxCSettingsBase* base, AtxZone* zonePtrs[]);
	void initialize(uint_fast8_t initZones);
	void setSetting(Setting newSetting);
	Setting getSetting(){return setting_;}
	void setFunction(uint8_t newFunc);
	uint8_t getFunction(){return function_[setting_];}
	void setParameterValue(uint_fast8_t parameter, int_fast16_t newValue);
	int_fast16_t getParameterValue(uint_fast8_t parameter){return getParameterValue(setting_,function_[setting_],parameter);}
	int_fast16_t getParameterValue(uint_fast8_t func, uint_fast8_t parameter){return getParameterValue(setting_,func,parameter);}
	int_fast16_t getParameterValue(uint_fast8_t setting, uint_fast8_t func, uint_fast8_t parameter);
	protected:
	private:
	AtxCSettings() {}
	AtxCSettings(AtxCSettingsBase* base, AtxZone* zonePtrs[]);
	~AtxCSettings();
	AtxCSettings( const AtxCSettings &c );
	AtxCSettings& operator=( const AtxCSettings &c );

}; //AtxCSettings

#endif //__ATXCSETTINGS_H__
