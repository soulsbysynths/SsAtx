/*
 * AtxCSettingsBase.h
 *
 * Created: 18/01/2018 11:52:08
 *  Author: info
 */ 


#ifndef ATXCSETTINGSBASE_H_
#define ATXCSETTINGSBASE_H_

class AtxCSettingsBase
{
	public:
	virtual void settingSettingChanged(uint_fast8_t setting) = 0;
	virtual void settingFunctionChanged(uint_fast8_t setting, uint_fast8_t func) = 0;
	virtual void settingParameterValueChanged(uint_fast8_t setting, uint_fast8_t parameter, int_fast16_t value) = 0;
};



#endif /* ATXCSETTINGSBASE_H_ */