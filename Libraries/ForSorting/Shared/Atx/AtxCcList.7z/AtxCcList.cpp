/*
* AtxCcList.cpp
*
* Created: 21/11/2021 12:37:11
* Author: info
*/


#include "AtxCcList.h"

namespace atx
{
	// default constructor
	AtxCcList::AtxCcList()
	{
	} //AtxCcList

	// default destructor
	AtxCcList::~AtxCcList()
	{
		clear();
		
	} //~AtxCcList
	void AtxCcList::clear()
	{
		free(ccList_);
		ccList_ = NULL;
		listSize_ = 0;
	}
	void AtxCcList::appendPoly(Firmware firmware, uint_fast8_t zone)
	{
		uint8_t newSize = listSize_;
		for(uint_fast8_t cc=0;cc<MAX_CCS;++cc)
		{
			if(AtxCcSet::getCcInfoCtrlEnabled(firmware,cc) && (zone==atx::UNUSED || zone==AtxCcSet::getCcInfoCtrlZone(firmware,cc)))
			{
				newSize++;
			}
		}
		if(newSize>=MAX_CCS) newSize = MAX_CCS;
		CcListInfo* newList = (CcListInfo*)malloc(newSize*sizeof(CcListInfo));
		memcpy(newList,ccList_,listSize_*sizeof(CcListInfo));
		free(ccList_);
		ccList_ = newList;
		for(uint_fast8_t cc=0;cc<MAX_CCS;++cc)
		{
			if(AtxCcSet::getCcInfoCtrlEnabled(firmware,cc) && (zone==atx::UNUSED || zone==AtxCcSet::getCcInfoCtrlZone(firmware,cc)))
			{
				ccList_[listSize_].firmware = firmware;
				ccList_[listSize_].cc = cc;
				listSize_++;
				if(listSize_>=MAX_CCS) break;
			}
		}		
	}
	CcListInfo AtxCcList::getCcListInfo(uint_fast8_t inCc)
	{
		uint8_t index = ((uint16_t)inCc * listSize_) >> 7;
		return ccList_[index];
	}
}
