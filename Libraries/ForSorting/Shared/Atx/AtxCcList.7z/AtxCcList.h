/*
* AtxCcList.h
*
* Created: 21/11/2021 12:37:12
* Author: info
*/


#ifndef __ATXCCLIST_H__
#define __ATXCCLIST_H__

#include <stdlib.h>
#include "Atx.h"
#include "AtxCcSet.h"

namespace atx
{
	typedef struct CcListInfo
	{
		//Firmware firmware;
		uint8_t channel;
		uint8_t cc;
	} CcListInfo;
	class AtxCcList
	{
		//variables
		public:
		protected:
		private:
		CcListInfo* ccList_ = NULL;
		uint8_t listSize_ = 0;
		//functions
		public:
		AtxCcList();
		~AtxCcList();
		void appendZone(Firmware firmware){AtxCcList::appendPoly(firmware,atx::UNUSED);}
		void appendPoly(Firmware firmware, uint_fast8_t zone);
		void clear();
		CcListInfo getCcListInfo(uint_fast8_t inCc);
		protected:
		private:
		AtxCcList( const AtxCcList &c );
		AtxCcList& operator=( const AtxCcList &c );
	}; //AtxCcList
}


#endif //__ATXCCLIST_H__
