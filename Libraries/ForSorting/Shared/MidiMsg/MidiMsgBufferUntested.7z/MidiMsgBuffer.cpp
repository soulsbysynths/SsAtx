/*
* MidiMsgBuffer.cpp
*
* Created: 15/08/2021 19:40:25
* Author: info
*/


#include "MidiMsgBuffer.h"
#include <string.h>

// default constructor
MidiMsgBuffer::MidiMsgBuffer()
{

} //AtxMsgBuffer
// default destructor

MidiMsgBuffer::~MidiMsgBuffer()
{

} //~AtxMsgBuffer
void MidiMsgBuffer::writeMidiMsg(const MidiMsg * msg)
{
	volatile int8_t i = nextIndex(head_);
	
	if ( i != tail_ )
	{
		memcpy(&midiMsgBuffer_[head_],msg,sizeof(MidiMsg))
		head_ = i ;
	}
}

bool MidiMsgBuffer::readAtxMsg(MidiMsg &destMsg)
{
	if(tail_ == head_)
	{
		return false;
	}
	else
	{
		uint8_t ind = tail_;
		tail_ = nextIndex(tail_);
		memcpy(&destMsg,&midiMsgBuffer_[ind],sizeof(MidiMsg));
		return true;
	}	
}

bool MidiMsgBuffer::peekAtxMsg(MidiMsg &destMsg)
{
	if(tail_ == head_)
	{
		return false;
	}
	else
	{
		memcpy(&destMsg,&midiMsgBuffer_[tail_],sizeof(MidiMsg));
		return true;
	}
}
void MidiMsgBuffer::clear()
{
	head_ = 0;
	tail_ = 0;
}

int8_t MidiMsgBuffer::available()
{
	int8_t delta = head_ - tail_;

	if(delta < 0)
	{
		return MSGBUFFER_SIZE + delta;
	}
	else
	{
		return delta;
	}
}

int8_t MidiMsgBuffer::availableForStore()
{
	if (head_ >= tail_)
	{
		return MSGBUFFER_SIZE - 1 - head_ + tail_;
	}
	else
	{
		return tail_ - head_ - 1;
	}
}

bool MidiMsgBuffer::isFull()
{
	return (nextIndex(head_) == tail_);
}

bool MidiMsgBuffer::isEmpty()
{
	return (head_ == tail_);
}