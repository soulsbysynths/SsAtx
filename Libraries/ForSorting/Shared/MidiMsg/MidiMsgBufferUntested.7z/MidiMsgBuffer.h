/*
* AtxMsgBuffer.h
*
* Created: 23/07/2019 19:40:25
* Author: info
*/


#ifndef __ATXMSGBUFFER_H__
#define __ATXMSGBUFFER_H__

#include "Atx.h"
#include "MidiMsg.h"
#include <stdint.h>
#include <stdlib.h>

class MidiMsgBuffer
{
	//variables
	public:
	protected:
	private:
	static const int8_t I2C_GENERAL_CALL = -8;
	static const int8_t MSGBUFFER_SIZE = 16;
	static const int8_t MSGBUFFER_MASK = (MSGBUFFER_SIZE - 1);
	volatile uint8_t midiMsgBuffer_[MSGBUFFER_SIZE] = {0};
	volatile int8_t head_ = 0;
	volatile int8_t tail_ = 0;

	//functions
	public:
	MidiMsgBuffer();
	~MidiMsgBuffer();
	void writeMidiMsg(const MidiMsg * msg);
	bool readMidiMsg(MidiMsg &destMsg);
	bool peekMidiMsg(MidiMsg &destMsg);
	void clear();
	int8_t available();
	int8_t availableForStore();
	bool isFull();
	bool isEmpty();
	protected:
	private:
	MidiMsgBuffer( const MidiMsgBuffer &c );
	MidiMsgBuffer& operator=( const MidiMsgBuffer &c );
	int8_t nextIndex(int8_t index) { return (uint8_t)(index + 1) & MSGBUFFER_MASK; }
}; //MidiMsgBuffer

#endif //__ATXMSGBUFFER_H__
